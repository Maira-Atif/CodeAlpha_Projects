// Dashboard Main Functionality
class RealEstateDashboard {
    constructor() {
        this.currentTimeRange = '30d';
        this.currentHeatMapView = 'price';
        this.data = {};
        this.charts = {};
        this.map = null;
        this.heatmapLayer = null;
        
        this.init();
    }

    async init() {
        await this.loadData();
        this.initializeEventListeners();
        this.initializeMap();
        this.renderPropertyList();
        this.updateStats();
        
        // Auto-refresh data every 5 minutes
        setInterval(() => {
            this.refreshData();
        }, 300000);
    }

    async loadData() {
        // Simulate loading real estate data
        this.data = {
            properties: this.generatePropertyData(),
            marketStats: this.generateMarketStats(),
            priceHistory: this.generatePriceHistory(),
            economicData: this.generateEconomicData(),
            heatmapData: this.generateHeatmapData()
        };
    }

    generatePropertyData() {
        const locations = [
            { name: 'Downtown Manhattan', lat: 40.7589, lng: -73.9851, basePrice: 850000 },
            { name: 'Brooklyn Heights', lat: 40.6962, lng: -73.9936, basePrice: 650000 },
            { name: 'Queens Village', lat: 40.7282, lng: -73.7949, basePrice: 450000 },
            { name: 'Bronx Park', lat: 40.8448, lng: -73.8648, basePrice: 380000 },
            { name: 'Staten Island', lat: 40.5795, lng: -74.1502, basePrice: 520000 },
            { name: 'Upper East Side', lat: 40.7736, lng: -73.9566, basePrice: 1200000 },
            { name: 'Chelsea', lat: 40.7465, lng: -73.9972, basePrice: 980000 },
            { name: 'SoHo', lat: 40.7234, lng: -74.0020, basePrice: 1500000 },
            { name: 'Greenwich Village', lat: 40.7335, lng: -74.0027, basePrice: 1350000 },
            { name: 'Williamsburg', lat: 40.7081, lng: -73.9571, basePrice: 750000 }
        ];

        const propertyTypes = ['Apartment', 'House', 'Condo', 'Townhouse', 'Loft'];
        
        return locations.map((location, index) => {
            const priceVariation = (Math.random() - 0.5) * 0.3; // ±15% variation
            const currentPrice = Math.round(location.basePrice * (1 + priceVariation));
            const yearlyChange = (Math.random() - 0.3) * 0.25; // Bias towards growth
            
            return {
                id: index + 1,
                name: location.name,
                type: propertyTypes[Math.floor(Math.random() * propertyTypes.length)],
                price: currentPrice,
                latitude: location.lat,
                longitude: location.lng,
                yearlyChange: yearlyChange,
                rentalYield: 4 + Math.random() * 4, // 4-8%
                daysOnMarket: Math.floor(Math.random() * 90) + 10,
                demand: Math.random() * 100,
                supply: Math.random() * 100
            };
        });
    }

    generateMarketStats() {
        return {
            avgPrice: 485000,
            avgPriceChange: 0.125,
            rentalYield: 6.8,
            rentalYieldChange: 0.003,
            marketDemand: 'High',
            marketDemandChange: 0.082,
            propertiesSold: 1247,
            propertiesSoldChange: -0.021
        };
    }

    generatePriceHistory() {
        const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 
                       'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        const currentYear = new Date().getFullYear();
        
        let basePrice = 420000;
        const data = [];
        
        for (let i = 0; i < 24; i++) {
            const monthIndex = (new Date().getMonth() - i + 24) % 12;
            const year = currentYear - Math.floor(i / 12);
            
            // Add some realistic market fluctuation
            const seasonalFactor = Math.sin((monthIndex / 12) * 2 * Math.PI) * 0.05;
            const trendFactor = i * 0.008; // General upward trend
            const randomFactor = (Math.random() - 0.5) * 0.02;
            
            basePrice = basePrice * (1 + seasonalFactor + trendFactor + randomFactor);
            
            data.unshift({
                label: `${months[monthIndex]} ${year}`,
                value: Math.round(basePrice)
            });
        }
        
        return data;
    }

    generateEconomicData() {
        return {
            interestRates: [2.1, 2.3, 2.5, 2.8, 3.1, 3.4, 3.2, 3.0, 2.9, 2.7, 2.5, 2.4],
            employment: [94.2, 94.5, 94.8, 95.1, 95.3, 95.0, 94.8, 94.6, 94.9, 95.2, 95.4, 95.6],
            population: [8.3, 8.32, 8.34, 8.36, 8.38, 8.4, 8.42, 8.44, 8.46, 8.48, 8.5, 8.52],
            gdp: [98, 101, 103, 105, 107, 104, 106, 108, 110, 112, 115, 118]
        };
    }

    generateHeatmapData() {
        const heatmapPoints = [];
        const baseLocations = [
            [40.7589, -73.9851], [40.6962, -73.9936], [40.7282, -73.7949],
            [40.8448, -73.8648], [40.5795, -74.1502], [40.7736, -73.9566],
            [40.7465, -73.9972], [40.7234, -74.0020], [40.7335, -74.0027],
            [40.7081, -73.9571]
        ];

        baseLocations.forEach(([lat, lng]) => {
            // Add multiple points around each base location
            for (let i = 0; i < 15; i++) {
                const offsetLat = lat + (Math.random() - 0.5) * 0.02;
                const offsetLng = lng + (Math.random() - 0.5) * 0.02;
                const intensity = Math.random();
                
                heatmapPoints.push([offsetLat, offsetLng, intensity]);
            }
        });

        return heatmapPoints;
    }

    initializeEventListeners() {
        // Time range selector
        document.getElementById('timeRange').addEventListener('change', (e) => {
            this.currentTimeRange = e.target.value;
            this.updateDashboard();
        });

        // Navigation links
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                this.updateActiveNav(link);
            });
        });

        // Chart option buttons
        document.querySelectorAll('.chart-option').forEach(button => {
            button.addEventListener('click', (e) => {
                if (e.target.textContent.includes('Refresh')) return;
                
                const container = button.closest('.chart-container');
                container.querySelectorAll('.chart-option').forEach(btn => {
                    btn.classList.remove('active');
                });
                button.classList.add('active');
            });
        });
    }

    initializeMap() {
        // Initialize Leaflet map
        this.map = L.map('map').setView([40.7128, -73.9352], 11);
        
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap contributors'
        }).addTo(this.map);

        // Add property markers
        this.data.properties.forEach(property => {
            const marker = L.marker([property.latitude, property.longitude])
                .bindPopup(`
                    <div style="padding: 10px;">
                        <h4>${property.name}</h4>
                        <p><strong>Type:</strong> ${property.type}</p>
                        <p><strong>Price:</strong> $${property.price.toLocaleString()}</p>
                        <p><strong>Change:</strong> <span style="color: ${property.yearlyChange >= 0 ? 'green' : 'red'}">
                            ${(property.yearlyChange * 100).toFixed(1)}%
                        </span></p>
                        <p><strong>Rental Yield:</strong> ${property.rentalYield.toFixed(1)}%</p>
                    </div>
                `);
            
            marker.addTo(this.map);
        });

        // Initialize heatmap
        this.updateHeatMap('price');
    }

    updateHeatMap(type) {
        this.currentHeatMapView = type;
        
        // Remove existing heatmap layer
        if (this.heatmapLayer) {
            this.map.removeLayer(this.heatmapLayer);
        }

        // Update button states
        const mapContainer = document.querySelector('.map-container');
        mapContainer.querySelectorAll('.chart-option').forEach(btn => {
            btn.classList.remove('active');
            if (btn.textContent.toLowerCase() === type) {
                btn.classList.add('active');
            }
        });

        // Add heatmap points based on type
        const heatmapData = this.data.heatmapData.map(([lat, lng, intensity]) => {
            let adjustedIntensity = intensity;
            
            switch(type) {
                case 'price':
                    adjustedIntensity = intensity * 0.8 + 0.2; // Price-based intensity
                    break;
                case 'demand':
                    adjustedIntensity = Math.pow(intensity, 0.7); // Demand-based intensity
                    break;
                case 'growth':
                    adjustedIntensity = intensity * 0.6 + Math.random() * 0.4; // Growth-based intensity
                    break;
            }
            
            return [lat, lng, Math.min(1, adjustedIntensity)];
        });

        // Create heatmap layer (using a simple circle overlay as heatmap simulation)
        this.heatmapLayer = L.layerGroup();
        
        heatmapData.forEach(([lat, lng, intensity]) => {
            const circle = L.circle([lat, lng], {
                color: this.getHeatmapColor(intensity),
                fillColor: this.getHeatmapColor(intensity),
                fillOpacity: intensity * 0.6,
                radius: 200 + (intensity * 300)
            });
            
            this.heatmapLayer.addLayer(circle);
        });
        
        this.heatmapLayer.addTo(this.map);
    }

    getHeatmapColor(intensity) {
        if (intensity < 0.3) return '#00ff00';
        if (intensity < 0.6) return '#ffff00';
        if (intensity < 0.8) return '#ff8000';
        return '#ff0000';
    }

    renderPropertyList() {
        const propertyList = document.getElementById('propertyList');
        const topProperties = this.data.properties
            .sort((a, b) => b.yearlyChange - a.yearlyChange)
            .slice(0, 8);

        propertyList.innerHTML = topProperties.map(property => `
            <div class="property-item">
                <div class="property-info">
                    <div class="property-name">${property.name}</div>
                    <div class="property-location">${property.type} • ${property.daysOnMarket} days on market</div>
                </div>
                <div class="property-price">$${property.price.toLocaleString()}</div>
                <div class="property-change ${property.yearlyChange >= 0 ? 'positive' : 'negative'}">
                    <i class="fas fa-arrow-${property.yearlyChange >= 0 ? 'up' : 'down'}"></i>
                    ${(property.yearlyChange * 100).toFixed(1)}%
                </div>
            </div>
        `).join('');
    }

    updateStats() {
        const stats = this.data.marketStats;
        
        document.getElementById('avgPrice').textContent = `$${stats.avgPrice.toLocaleString()}`;
        document.getElementById('rentalYield').textContent = `${stats.rentalYield}%`;
        document.getElementById('marketDemand').textContent = stats.marketDemand;
        document.getElementById('propertiesSold').textContent = stats.propertiesSold.toLocaleString();
    }

    updateActiveNav(activeLink) {
        document.querySelectorAll('.nav-link').forEach(link => {
            link.classList.remove('active');
        });
        activeLink.classList.add('active');
    }

    async refreshData() {
        const refreshButton = document.querySelector('button[onclick="refreshData()"]');
        const originalContent = refreshButton.innerHTML;
        
        refreshButton.innerHTML = '<div class="spinner"></div> Refreshing...';
        refreshButton.disabled = true;

        // Simulate data refresh delay
        await new Promise(resolve => setTimeout(resolve, 1500));

        await this.loadData();
        this.updateDashboard();
        this.renderPropertyList();
        this.updateStats();

        refreshButton.innerHTML = originalContent;
        refreshButton.disabled = false;
    }

    updateDashboard() {
        // Update charts with new time range
        if (window.chartManager) {
            window.chartManager.updateAllCharts(this.currentTimeRange, this.data);
        }
        
        // Update heatmap
        this.updateHeatMap(this.currentHeatMapView);
    }
}

// Global functions for HTML onclick handlers
window.refreshData = function() {
    if (window.dashboard) {
        window.dashboard.refreshData();
    }
};

window.updateChart = function(chartType, timeframe) {
    if (window.chartManager) {
        window.chartManager.updateChart(chartType, timeframe);
    }
};

window.updateHeatMap = function(type) {
    if (window.dashboard) {
        window.dashboard.updateHeatMap(type);
    }
};
