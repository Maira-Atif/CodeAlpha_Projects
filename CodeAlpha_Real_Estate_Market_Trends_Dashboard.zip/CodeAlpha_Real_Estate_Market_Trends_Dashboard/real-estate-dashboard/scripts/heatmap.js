// Heatmap functionality for Real Estate Dashboard
class HeatmapManager {
    constructor(map) {
        this.map = map;
        this.heatmapLayers = {
            price: null,
            demand: null,
            growth: null
        };
        this.currentLayer = 'price';
        
        this.initializeHeatmapData();
    }

    initializeHeatmapData() {
        // Generate realistic real estate heatmap data for NYC
        this.heatmapData = {
            price: this.generatePriceHeatmapData(),
            demand: this.generateDemandHeatmapData(),
            growth: this.generateGrowthHeatmapData()
        };
    }

    generatePriceHeatmapData() {
        // NYC neighborhoods with price intensity
        const priceHotspots = [
            // Manhattan (high prices)
            { lat: 40.7831, lng: -73.9712, intensity: 0.95 }, // Upper East Side
            { lat: 40.7505, lng: -73.9934, intensity: 0.88 }, // Midtown
            { lat: 40.7282, lng: -74.0776, intensity: 0.92 }, // Tribeca
            { lat: 40.7359, lng: -74.0014, intensity: 0.85 }, // Greenwich Village
            { lat: 40.7505, lng: -73.9776, intensity: 0.82 }, // Times Square area
            
            // Brooklyn (varied prices)
            { lat: 40.6892, lng: -73.9442, intensity: 0.75 }, // DUMBO
            { lat: 40.7081, lng: -73.9571, intensity: 0.72 }, // Williamsburg
            { lat: 40.6782, lng: -73.9442, intensity: 0.68 }, // Brooklyn Heights
            { lat: 40.6892, lng: -73.9951, intensity: 0.45 }, // Sunset Park
            
            // Queens (moderate prices)
            { lat: 40.7282, lng: -73.7949, intensity: 0.35 }, // Flushing
            { lat: 40.7648, lng: -73.8370, intensity: 0.42 }, // Astoria
            { lat: 40.7282, lng: -73.8370, intensity: 0.38 }, // Elmhurst
            
            // Bronx (lower prices)
            { lat: 40.8448, lng: -73.8648, intensity: 0.25 }, // Bronx Park
            { lat: 40.8272, lng: -73.9274, intensity: 0.22 }, // Concourse
            
            // Staten Island (moderate prices)
            { lat: 40.5795, lng: -74.1502, intensity: 0.35 }
        ];

        return this.expandHeatmapPoints(priceHotspots);
    }

    generateDemandHeatmapData() {
        // Areas with high buyer demand
        const demandHotspots = [
            // High demand areas
            { lat: 40.7081, lng: -73.9571, intensity: 0.92 }, // Williamsburg
            { lat: 40.7505, lng: -73.9776, intensity: 0.88 }, // Midtown
            { lat: 40.7648, lng: -73.8370, intensity: 0.85 }, // Astoria
            { lat: 40.6892, lng: -73.9442, intensity: 0.82 }, // DUMBO
            { lat: 40.7359, lng: -74.0014, intensity: 0.78 }, // Greenwich Village
            
            // Moderate demand
            { lat: 40.7282, lng: -73.7949, intensity: 0.65 }, // Flushing
            { lat: 40.6782, lng: -73.9442, intensity: 0.62 }, // Brooklyn Heights
            { lat: 40.5795, lng: -74.1502, intensity: 0.58 }, // Staten Island
            
            // Lower demand
            { lat: 40.8448, lng: -73.8648, intensity: 0.35 }, // Bronx
            { lat: 40.8272, lng: -73.9274, intensity: 0.32 }
        ];

        return this.expandHeatmapPoints(demandHotspots);
    }

    generateGrowthHeatmapData() {
        // Areas with high growth potential
        const growthHotspots = [
            // Emerging neighborhoods
            { lat: 40.6892, lng: -73.9951, intensity: 0.88 }, // Sunset Park
            { lat: 40.7282, lng: -73.8370, intensity: 0.85 }, // Elmhurst
            { lat: 40.8448, lng: -73.8648, intensity: 0.82 }, // Bronx (gentrification)
            { lat: 40.7648, lng: -73.8370, intensity: 0.78 }, // Astoria
            { lat: 40.6590, lng: -73.9759, intensity: 0.75 }, // Red Hook
            
            // Steady growth
            { lat: 40.7081, lng: -73.9571, intensity: 0.65 }, // Williamsburg
            { lat: 40.6892, lng: -73.9442, intensity: 0.62 }, // DUMBO
            { lat: 40.5795, lng: -74.1502, intensity: 0.58 }, // Staten Island
            
            // Mature markets (lower growth)
            { lat: 40.7831, lng: -73.9712, intensity: 0.35 }, // Upper East Side
            { lat: 40.7282, lng: -74.0776, intensity: 0.32 }  // Tribeca
        ];

        return this.expandHeatmapPoints(growthHotspots);
    }

    expandHeatmapPoints(hotspots) {
        const expandedPoints = [];
        
        hotspots.forEach(hotspot => {
            // Add the main point
            expandedPoints.push([hotspot.lat, hotspot.lng, hotspot.intensity]);
            
            // Add surrounding points for better heatmap effect
            for (let i = 0; i < 12; i++) {
                const angle = (i / 12) * 2 * Math.PI;
                const distance = 0.005 + Math.random() * 0.01; // Random distance up to ~1km
                
                const newLat = hotspot.lat + Math.cos(angle) * distance;
                const newLng = hotspot.lng + Math.sin(angle) * distance;
                const newIntensity = hotspot.intensity * (0.3 + Math.random() * 0.4);
                
                expandedPoints.push([newLat, newLng, newIntensity]);
            }
        });
        
        return expandedPoints;
    }

    createHeatmapLayer(type) {
        if (this.heatmapLayers[type]) {
            return this.heatmapLayers[type];
        }

        const layerGroup = L.layerGroup();
        const data = this.heatmapData[type];
        
        data.forEach(([lat, lng, intensity]) => {
            const circle = L.circle([lat, lng], {
                color: this.getHeatmapColor(intensity, type),
                fillColor: this.getHeatmapColor(intensity, type),
                fillOpacity: intensity * 0.6,
                stroke: false,
                radius: 150 + (intensity * 250)
            });
            
            // Add tooltip with relevant information
            const tooltipContent = this.getTooltipContent(type, intensity, lat, lng);
            circle.bindTooltip(tooltipContent, {
                permanent: false,
                direction: 'top',
                className: 'heatmap-tooltip'
            });
            
            layerGroup.addLayer(circle);
        });
        
        this.heatmapLayers[type] = layerGroup;
        return layerGroup;
    }

    getHeatmapColor(intensity, type) {
        let colors;
        
        switch(type) {
            case 'price':
                colors = ['#00ff00', '#66ff00', '#ccff00', '#ffcc00', '#ff6600', '#ff0000'];
                break;
            case 'demand':
                colors = ['#0066ff', '#0099ff', '#00ccff', '#66ccff', '#99ccff', '#ccccff'];
                break;
            case 'growth':
                colors = ['#9900ff', '#cc00ff', '#ff00cc', '#ff0099', '#ff0066', '#ff0033'];
                break;
            default:
                colors = ['#00ff00', '#ffff00', '#ff8000', '#ff0000'];
        }
        
        const index = Math.min(Math.floor(intensity * colors.length), colors.length - 1);
        return colors[index];
    }

    getTooltipContent(type, intensity, lat, lng) {
        const neighborhood = this.getNeighborhoodName(lat, lng);
        
        switch(type) {
            case 'price':
                const priceLevel = intensity > 0.8 ? 'Very High' : 
                                 intensity > 0.6 ? 'High' : 
                                 intensity > 0.4 ? 'Moderate' : 'Low';
                const avgPrice = Math.round(300000 + (intensity * 700000));
                return `
                    <strong>${neighborhood}</strong><br>
                    Price Level: ${priceLevel}<br>
                    Avg Price: $${avgPrice.toLocaleString()}
                `;
                
            case 'demand':
                const demandLevel = intensity > 0.8 ? 'Very High' : 
                                  intensity > 0.6 ? 'High' : 
                                  intensity > 0.4 ? 'Moderate' : 'Low';
                const daysOnMarket = Math.round(90 - (intensity * 70));
                return `
                    <strong>${neighborhood}</strong><br>
                    Demand Level: ${demandLevel}<br>
                    Avg Days on Market: ${daysOnMarket}
                `;
                
            case 'growth':
                const growthRate = (intensity * 15).toFixed(1);
                const potentialLevel = intensity > 0.8 ? 'Excellent' : 
                                     intensity > 0.6 ? 'Good' : 
                                     intensity > 0.4 ? 'Fair' : 'Limited';
                return `
                    <strong>${neighborhood}</strong><br>
                    Growth Potential: ${potentialLevel}<br>
                    Projected Growth: ${growthRate}%/year
                `;
                
            default:
                return `<strong>${neighborhood}</strong>`;
        }
    }

    getNeighborhoodName(lat, lng) {
        // Simple mapping based on coordinates
        if (lat > 40.75) return 'Upper Manhattan';
        if (lat > 40.72 && lng > -73.98) return 'Midtown';
        if (lat > 40.72 && lng < -74.00) return 'Lower Manhattan';
        if (lat > 40.68 && lat < 40.72 && lng > -73.98) return 'Brooklyn';
        if (lat > 40.75 && lng < -73.85) return 'Queens';
        if (lat > 40.82) return 'Bronx';
        if (lat < 40.62) return 'Staten Island';
        return 'NYC Area';
    }

    showHeatmap(type) {
        // Hide current layer
        if (this.currentLayer && this.heatmapLayers[this.currentLayer]) {
            this.map.removeLayer(this.heatmapLayers[this.currentLayer]);
        }
        
        // Show new layer
        const layer = this.createHeatmapLayer(type);
        this.map.addLayer(layer);
        this.currentLayer = type;
        
        // Add legend
        this.updateLegend(type);
    }

    updateLegend(type) {
        // Remove existing legend
        const existingLegend = document.querySelector('.heatmap-legend');
        if (existingLegend) {
            existingLegend.remove();
        }
        
        // Create new legend
        const legend = document.createElement('div');
        legend.className = 'heatmap-legend';
        legend.style.cssText = `
            position: absolute;
            bottom: 20px;
            right: 20px;
            background: white;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            z-index: 1000;
            font-size: 12px;
            min-width: 150px;
        `;
        
        const title = document.createElement('div');
        title.style.cssText = 'font-weight: bold; margin-bottom: 10px; text-transform: capitalize;';
        title.textContent = `${type} Intensity`;
        legend.appendChild(title);
        
        const colors = this.getHeatmapColor(0.8, type);
        const levels = ['Low', 'Moderate', 'High', 'Very High'];
        const colorValues = [0.2, 0.4, 0.7, 0.9];
        
        levels.forEach((level, index) => {
            const item = document.createElement('div');
            item.style.cssText = 'display: flex; align-items: center; margin: 5px 0;';
            
            const colorBox = document.createElement('div');
            colorBox.style.cssText = `
                width: 16px; 
                height: 16px; 
                background: ${this.getHeatmapColor(colorValues[index], type)}; 
                margin-right: 8px; 
                border-radius: 2px;
            `;
            
            const label = document.createElement('span');
            label.textContent = level;
            
            item.appendChild(colorBox);
            item.appendChild(label);
            legend.appendChild(item);
        });
        
        document.getElementById('map').appendChild(legend);
    }

    // Clean up method
    destroy() {
        Object.values(this.heatmapLayers).forEach(layer => {
            if (layer) {
                this.map.removeLayer(layer);
            }
        });
        
        const legend = document.querySelector('.heatmap-legend');
        if (legend) {
            legend.remove();
        }
    }
}

// Add custom CSS for heatmap tooltips
const heatmapStyles = document.createElement('style');
heatmapStyles.textContent = `
    .heatmap-tooltip {
        background: rgba(0, 0, 0, 0.8) !important;
        color: white !important;
        border: none !important;
        border-radius: 6px !important;
        font-size: 12px !important;
        padding: 8px 12px !important;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3) !important;
    }
    
    .heatmap-tooltip::before {
        border-top-color: rgba(0, 0, 0, 0.8) !important;
    }
`;
document.head.appendChild(heatmapStyles);
