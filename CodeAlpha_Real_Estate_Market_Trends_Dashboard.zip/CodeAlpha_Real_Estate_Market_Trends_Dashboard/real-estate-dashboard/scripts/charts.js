// Chart Management for Real Estate Dashboard
class ChartManager {
    constructor() {
        this.charts = {};
        this.colors = {
            primary: '#3b82f6',
            secondary: '#10b981',
            accent: '#f59e0b',
            danger: '#ef4444',
            gradient: {
                primary: ['#3b82f6', '#1d4ed8'],
                secondary: ['#10b981', '#047857'],
                accent: ['#f59e0b', '#d97706']
            }
        };
        
        this.initializeCharts();
    }

    initializeCharts() {
        this.createPriceChart();
        this.createPropertyTypeChart();
        this.createSupplyDemandChart();
        this.createEconomicChart();
    }

    createPriceChart() {
        const ctx = document.getElementById('priceChart').getContext('2d');
        
        // Generate sample price data
        const priceData = this.generatePriceData();
        
        this.charts.price = new Chart(ctx, {
            type: 'line',
            data: {
                labels: priceData.labels,
                datasets: [{
                    label: 'Average Price',
                    data: priceData.values,
                    borderColor: this.colors.primary,
                    backgroundColor: this.createGradient(ctx, this.colors.gradient.primary),
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4,
                    pointBackgroundColor: this.colors.primary,
                    pointBorderColor: '#ffffff',
                    pointBorderWidth: 2,
                    pointRadius: 5,
                    pointHoverRadius: 8
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        titleColor: '#ffffff',
                        bodyColor: '#ffffff',
                        borderColor: this.colors.primary,
                        borderWidth: 1,
                        cornerRadius: 6,
                        displayColors: false,
                        callbacks: {
                            label: function(context) {
                                return `$${context.parsed.y.toLocaleString()}`;
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        grid: {
                            display: false
                        },
                        ticks: {
                            color: '#6b7280'
                        }
                    },
                    y: {
                        grid: {
                            color: 'rgba(107, 114, 128, 0.1)'
                        },
                        ticks: {
                            color: '#6b7280',
                            callback: function(value) {
                                return '$' + (value / 1000).toFixed(0) + 'K';
                            }
                        }
                    }
                },
                interaction: {
                    intersect: false,
                    mode: 'index'
                }
            }
        });
    }

    createPropertyTypeChart() {
        const ctx = document.getElementById('propertyTypeChart').getContext('2d');
        
        const propertyData = {
            labels: ['Apartments', 'Houses', 'Condos', 'Townhouses', 'Lofts'],
            values: [35, 25, 20, 15, 5]
        };

        this.charts.propertyType = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: propertyData.labels,
                datasets: [{
                    data: propertyData.values,
                    backgroundColor: [
                        this.colors.primary,
                        this.colors.secondary,
                        this.colors.accent,
                        '#ec4899',
                        '#8b5cf6'
                    ],
                    borderWidth: 0,
                    hoverBorderWidth: 2,
                    hoverBorderColor: '#ffffff'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            usePointStyle: true,
                            padding: 20,
                            color: '#374151'
                        }
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        titleColor: '#ffffff',
                        bodyColor: '#ffffff',
                        cornerRadius: 6,
                        callbacks: {
                            label: function(context) {
                                return `${context.label}: ${context.parsed}%`;
                            }
                        }
                    }
                },
                cutout: '60%'
            }
        });
    }

    createSupplyDemandChart() {
        const ctx = document.getElementById('supplyDemandChart').getContext('2d');
        
        const supplyDemandData = this.generateSupplyDemandData();
        
        this.charts.supplyDemand = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: supplyDemandData.labels,
                datasets: [
                    {
                        label: 'Supply',
                        data: supplyDemandData.supply,
                        backgroundColor: this.colors.accent,
                        borderRadius: 4,
                        borderSkipped: false,
                    },
                    {
                        label: 'Demand',
                        data: supplyDemandData.demand,
                        backgroundColor: this.colors.secondary,
                        borderRadius: 4,
                        borderSkipped: false,
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: true,
                        position: 'top',
                        labels: {
                            usePointStyle: true,
                            color: '#374151'
                        }
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        titleColor: '#ffffff',
                        bodyColor: '#ffffff',
                        cornerRadius: 6
                    }
                },
                scales: {
                    x: {
                        grid: {
                            display: false
                        },
                        ticks: {
                            color: '#6b7280'
                        }
                    },
                    y: {
                        grid: {
                            color: 'rgba(107, 114, 128, 0.1)'
                        },
                        ticks: {
                            color: '#6b7280'
                        }
                    }
                }
            }
        });
    }

    createEconomicChart() {
        const ctx = document.getElementById('economicChart').getContext('2d');
        
        const economicData = this.generateEconomicData();
        
        this.charts.economic = new Chart(ctx, {
            type: 'line',
            data: {
                labels: economicData.labels,
                datasets: [
                    {
                        label: 'Interest Rate (%)',
                        data: economicData.interestRate,
                        borderColor: this.colors.danger,
                        backgroundColor: 'transparent',
                        borderWidth: 2,
                        tension: 0.4,
                        yAxisID: 'y'
                    },
                    {
                        label: 'Employment Rate (%)',
                        data: economicData.employment,
                        borderColor: this.colors.secondary,
                        backgroundColor: 'transparent',
                        borderWidth: 2,
                        tension: 0.4,
                        yAxisID: 'y1'
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: true,
                        position: 'top',
                        labels: {
                            usePointStyle: true,
                            color: '#374151'
                        }
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        titleColor: '#ffffff',
                        bodyColor: '#ffffff',
                        cornerRadius: 6
                    }
                },
                scales: {
                    x: {
                        grid: {
                            display: false
                        },
                        ticks: {
                            color: '#6b7280'
                        }
                    },
                    y: {
                        type: 'linear',
                        display: true,
                        position: 'left',
                        grid: {
                            color: 'rgba(107, 114, 128, 0.1)'
                        },
                        ticks: {
                            color: '#6b7280'
                        }
                    },
                    y1: {
                        type: 'linear',
                        display: true,
                        position: 'right',
                        grid: {
                            drawOnChartArea: false,
                        },
                        ticks: {
                            color: '#6b7280'
                        }
                    }
                }
            }
        });
    }

    generatePriceData() {
        const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 
                       'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        const labels = [];
        const values = [];
        
        let basePrice = 420000;
        
        for (let i = 0; i < 12; i++) {
            labels.push(months[i]);
            
            // Add realistic price variation
            const seasonalFactor = Math.sin((i / 12) * 2 * Math.PI) * 0.03;
            const trendFactor = i * 0.015;
            const randomFactor = (Math.random() - 0.5) * 0.02;
            
            basePrice = basePrice * (1 + seasonalFactor + trendFactor + randomFactor);
            values.push(Math.round(basePrice));
        }
        
        return { labels, values };
    }

    generateSupplyDemandData() {
        const neighborhoods = ['Manhattan', 'Brooklyn', 'Queens', 'Bronx', 'Staten Island'];
        const supply = [];
        const demand = [];
        
        neighborhoods.forEach(() => {
            supply.push(Math.floor(Math.random() * 80) + 20);
            demand.push(Math.floor(Math.random() * 90) + 30);
        });
        
        return {
            labels: neighborhoods,
            supply,
            demand
        };
    }

    generateEconomicData() {
        const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'];
        const interestRate = [2.5, 2.7, 2.9, 3.1, 2.8, 2.6];
        const employment = [94.2, 94.5, 94.8, 95.1, 95.3, 95.0];
        
        return {
            labels: months,
            interestRate,
            employment
        };
    }

    createGradient(ctx, colors) {
        const gradient = ctx.createLinearGradient(0, 0, 0, 400);
        gradient.addColorStop(0, colors[0] + '40');
        gradient.addColorStop(1, colors[1] + '00');
        return gradient;
    }

    updateChart(chartType, timeframe) {
        const chart = this.charts[chartType];
        if (!chart) return;

        // Update chart options buttons
        const chartContainer = chart.canvas.closest('.chart-container');
        chartContainer.querySelectorAll('.chart-option').forEach(btn => {
            btn.classList.remove('active');
            if (btn.textContent.toLowerCase() === timeframe) {
                btn.classList.add('active');
            }
        });

        // Generate new data based on timeframe
        let newData;
        
        switch(chartType) {
            case 'price':
                newData = timeframe === 'yearly' ? 
                    this.generateYearlyPriceData() : 
                    this.generatePriceData();
                break;
            default:
                return;
        }

        // Update chart data
        chart.data.labels = newData.labels;
        chart.data.datasets[0].data = newData.values;
        chart.update('active');
    }

    generateYearlyPriceData() {
        const years = [];
        const values = [];
        const currentYear = new Date().getFullYear();
        
        let basePrice = 350000;
        
        for (let i = 4; i >= 0; i--) {
            years.push((currentYear - i).toString());
            
            const yearlyGrowth = 0.08 + (Math.random() - 0.5) * 0.04;
            basePrice = basePrice * (1 + yearlyGrowth);
            values.push(Math.round(basePrice));
        }
        
        return { labels: years, values };
    }

    updateAllCharts(timeRange, data) {
        // Update charts based on new time range and data
        Object.keys(this.charts).forEach(chartKey => {
            const chart = this.charts[chartKey];
            
            // Add animation
            chart.update('active');
        });
    }    // Destroy all charts (useful for cleanup)
    destroyAllCharts() {
        Object.values(this.charts).forEach(chart => {
            chart.destroy();
        });
        this.charts = {};
    }
}
