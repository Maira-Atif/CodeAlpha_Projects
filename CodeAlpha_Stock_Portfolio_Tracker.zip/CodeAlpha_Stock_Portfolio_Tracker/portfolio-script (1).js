// Portfolio data storage
let portfolio = JSON.parse(localStorage.getItem('portfolio')) || [];
let stockPrices = {};

// Wait for DOM to load
document.addEventListener('DOMContentLoaded', function() {
    initializePortfolio();
    setupEventListeners();
    loadPortfolioData();
    updatePortfolioDisplay();
});

function initializePortfolio() {
    // Mobile menu toggle
    const hamburger = document.querySelector('.hamburger');
    const navMenu = document.querySelector('.nav-menu');
    
    hamburger.addEventListener('click', function() {
        hamburger.classList.toggle('active');
        navMenu.classList.toggle('active');
    });
    
    // Close mobile menu when clicking on a link
    document.querySelectorAll('.nav-link').forEach(n => n.addEventListener('click', () => {
        hamburger.classList.remove('active');
        navMenu.classList.remove('active');
    }));
    
    // Smooth scrolling for navigation links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
    
    // Navbar background on scroll
    window.addEventListener('scroll', function() {
        const navbar = document.querySelector('.navbar');
        if (window.scrollY > 100) {
            navbar.style.background = 'rgba(255, 255, 255, 0.98)';
            navbar.style.boxShadow = '0 2px 20px rgba(0, 0, 0, 0.1)';
        } else {
            navbar.style.background = 'rgba(255, 255, 255, 0.95)';
            navbar.style.boxShadow = 'none';
        }
    });
}

function setupEventListeners() {
    // Stock form submission
    const stockForm = document.getElementById('stockForm');
    stockForm.addEventListener('submit', function(e) {
        e.preventDefault();
        addStock();
    });
    
    // Contact form handling
    const contactForm = document.getElementById('contactForm');
    contactForm.addEventListener('submit', function(e) {
        e.preventDefault();
        handleContactForm();
    });
    
    // Modal functionality
    const modal = document.getElementById('stockModal');
    const closeBtn = document.querySelector('.close');
    
    closeBtn.addEventListener('click', function() {
        modal.style.display = 'none';
        document.body.style.overflow = 'auto';
    });
    
    window.addEventListener('click', function(e) {
        if (e.target === modal) {
            modal.style.display = 'none';
            document.body.style.overflow = 'auto';
        }
    });
}

async function addStock() {
    const symbol = document.getElementById('stockSymbol').value.toUpperCase().trim();
    const shares = parseFloat(document.getElementById('stockShares').value);
    const purchasePrice = parseFloat(document.getElementById('stockPrice').value);
    
    if (!symbol || !shares || !purchasePrice) {
        showNotification('Please fill in all fields', 'error');
        return;
    }
    
    // Check if stock already exists
    const existingStock = portfolio.find(stock => stock.symbol === symbol);
    if (existingStock) {
        showNotification('Stock already exists in portfolio', 'error');
        return;
    }
    
    // Add loading state
    const submitBtn = document.querySelector('#stockForm button[type="submit"]');
    const originalText = submitBtn.textContent;
    submitBtn.innerHTML = '<span class="spinner"></span> Adding...';
    submitBtn.disabled = true;
    
    try {
        // Get current stock price (simulated - in real app would use API)
        const currentPrice = await getCurrentStockPrice(symbol);
        
        const newStock = {
            id: Date.now(),
            symbol: symbol,
            shares: shares,
            purchasePrice: purchasePrice,
            currentPrice: currentPrice,
            dateAdded: new Date().toISOString()
        };
        
        portfolio.push(newStock);
        savePortfolio();
        updatePortfolioDisplay();
        
        // Reset form
        document.getElementById('stockForm').reset();
        showNotification(`${symbol} added to portfolio successfully!`, 'success');
        
    } catch (error) {
        showNotification('Error adding stock. Please try again.', 'error');
        console.error('Error adding stock:', error);
    } finally {
        submitBtn.textContent = originalText;
        submitBtn.disabled = false;
    }
}

async function getCurrentStockPrice(symbol) {
    // Simulate API call with random price generation
    // In a real application, you would use a financial API like Alpha Vantage, IEX Cloud, etc.
    
    return new Promise((resolve) => {
        setTimeout(() => {
            // Generate realistic stock prices based on symbol
            const basePrices = {
                'AAPL': 150,
                'GOOGL': 2500,
                'MSFT': 300,
                'AMZN': 3200,
                'TSLA': 800,
                'META': 250,
                'NFLX': 400,
                'NVDA': 500,
                'CRM': 180,
                'UBER': 45
            };
            
            let basePrice = basePrices[symbol] || (Math.random() * 200 + 50);
            // Add some random variation (+/- 5%)
            const variation = (Math.random() - 0.5) * 0.1;
            const currentPrice = basePrice * (1 + variation);
            
            stockPrices[symbol] = currentPrice;
            resolve(parseFloat(currentPrice.toFixed(2)));
        }, 1000);
    });
}

function deleteStock(stockId) {
    if (confirm('Are you sure you want to remove this stock from your portfolio?')) {
        portfolio = portfolio.filter(stock => stock.id !== stockId);
        savePortfolio();
        updatePortfolioDisplay();
        showNotification('Stock removed from portfolio', 'success');
    }
}

function savePortfolio() {
    localStorage.setItem('portfolio', JSON.stringify(portfolio));
}

async function loadPortfolioData() {
    if (portfolio.length === 0) return;
    
    // Update current prices for all stocks
    for (let stock of portfolio) {
        try {
            const currentPrice = await getCurrentStockPrice(stock.symbol);
            stock.currentPrice = currentPrice;
        } catch (error) {
            console.error(`Error updating price for ${stock.symbol}:`, error);
        }
    }
    
    savePortfolio();
    updatePortfolioDisplay();
}

function updatePortfolioDisplay() {
    updateStockTable();
    updatePortfolioSummary();
    updateHeroStats();
}

function updateStockTable() {
    const tableBody = document.getElementById('stockTableBody');
    
    if (portfolio.length === 0) {
        tableBody.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-chart-pie"></i>
                <p>No stocks in your portfolio yet. Add your first stock above!</p>
            </div>
        `;
        return;
    }
    
    tableBody.innerHTML = portfolio.map(stock => {
        const totalValue = stock.shares * stock.currentPrice;
        const totalCost = stock.shares * stock.purchasePrice;
        const gainLoss = totalValue - totalCost;
        const gainLossPercent = ((gainLoss / totalCost) * 100).toFixed(2);
        const isPositive = gainLoss >= 0;
        
        return `
            <div class="stock-row">
                <span class="stock-symbol">${stock.symbol}</span>
                <span>${stock.shares}</span>
                <span>$${stock.purchasePrice.toFixed(2)}</span>
                <span>$${stock.currentPrice.toFixed(2)}</span>
                <span>$${totalValue.toFixed(2)}</span>
                <span class="${isPositive ? 'positive' : 'negative'}">
                    ${isPositive ? '+' : ''}$${gainLoss.toFixed(2)} (${gainLossPercent}%)
                </span>
                <button class="delete-btn" onclick="deleteStock(${stock.id})">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        `;
    }).join('');
}

function updatePortfolioSummary() {
    if (portfolio.length === 0) {
        document.getElementById('totalInvestment').textContent = '$0.00';
        document.getElementById('currentValue').textContent = '$0.00';
        document.getElementById('totalGainLoss').textContent = '$0.00';
        document.getElementById('percentageChange').textContent = '0.00%';
        return;
    }
    
    const totalInvestment = portfolio.reduce((sum, stock) => sum + (stock.shares * stock.purchasePrice), 0);
    const currentValue = portfolio.reduce((sum, stock) => sum + (stock.shares * stock.currentPrice), 0);
    const totalGainLoss = currentValue - totalInvestment;
    const percentageChange = ((totalGainLoss / totalInvestment) * 100).toFixed(2);
    const isPositive = totalGainLoss >= 0;
    
    document.getElementById('totalInvestment').textContent = `$${totalInvestment.toFixed(2)}`;
    document.getElementById('currentValue').textContent = `$${currentValue.toFixed(2)}`;
    
    const gainLossElement = document.getElementById('totalGainLoss');
    gainLossElement.textContent = `${isPositive ? '+' : ''}$${totalGainLoss.toFixed(2)}`;
    gainLossElement.className = isPositive ? 'positive' : 'negative';
    
    const percentElement = document.getElementById('percentageChange');
    percentElement.textContent = `${isPositive ? '+' : ''}${percentageChange}%`;
    percentElement.className = isPositive ? 'positive' : 'negative';
}

function updateHeroStats() {
    const currentValue = portfolio.reduce((sum, stock) => sum + (stock.shares * stock.currentPrice), 0);
    const totalInvestment = portfolio.reduce((sum, stock) => sum + (stock.shares * stock.purchasePrice), 0);
    const dailyChange = currentValue - totalInvestment;
    const dailyChangePercent = totalInvestment > 0 ? ((dailyChange / totalInvestment) * 100).toFixed(2) : 0;
    const isPositive = dailyChange >= 0;
    
    document.getElementById('totalValue').textContent = `$${currentValue.toFixed(0)}`;
    
    const dailyChangeElement = document.getElementById('dailyChange');
    dailyChangeElement.textContent = `${isPositive ? '+' : ''}${dailyChangePercent}%`;
    dailyChangeElement.style.color = isPositive ? '#10b981' : '#ef4444';
    
    document.getElementById('stockCount').textContent = portfolio.length;
}

function handleContactForm() {
    const formData = new FormData(document.getElementById('contactForm'));
    const name = formData.get('name');
    const email = formData.get('email');
    const subject = formData.get('subject');
    const message = formData.get('message');
    
    if (!name || !email || !subject || !message) {
        showNotification('Please fill in all fields.', 'error');
        return;
    }
    
    if (!isValidEmail(email)) {
        showNotification('Please enter a valid email address.', 'error');
        return;
    }
    
    // Simulate form submission
    showNotification('Message sent successfully! I\'ll get back to you soon.', 'success');
    document.getElementById('contactForm').reset();
}

function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

function showNotification(message, type) {
    // Remove existing notifications
    const existingNotification = document.querySelector('.notification');
    if (existingNotification) {
        existingNotification.remove();
    }
    
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    
    // Add styles
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 15px 20px;
        border-radius: 8px;
        color: white;
        font-weight: 500;
        z-index: 9999;
        transition: all 0.3s ease;
        transform: translateX(300px);
        ${type === 'success' ? 'background: #10b981;' : 'background: #ef4444;'}
    `;
    
    document.body.appendChild(notification);
    
    // Animate in
    setTimeout(() => {
        notification.style.transform = 'translateX(0)';
    }, 100);
    
    // Remove after 5 seconds
    setTimeout(() => {
        notification.style.transform = 'translateX(300px)';
        setTimeout(() => {
            notification.remove();
        }, 300);
    }, 5000);
}

// Auto-update stock prices every 30 seconds
setInterval(() => {
    if (portfolio.length > 0) {
        loadPortfolioData();
    }
}, 30000);

// Intersection Observer for animations
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver(function(entries) {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('fade-in');
        }
    });
}, observerOptions);

// Observe elements for animation
document.querySelectorAll('.project-card, .skill-item, .stat, .summary-card').forEach(el => {
    observer.observe(el);
});

// Sample portfolio data for demo (uncomment to add sample data)
function addSampleData() {
    if (portfolio.length === 0) {
        const sampleStocks = [
            { symbol: 'AAPL', shares: 10, purchasePrice: 145.50 },
            { symbol: 'GOOGL', shares: 2, purchasePrice: 2400.00 },
            { symbol: 'MSFT', shares: 5, purchasePrice: 295.00 }
        ];
        
        sampleStocks.forEach(async (stock, index) => {
            setTimeout(async () => {
                const currentPrice = await getCurrentStockPrice(stock.symbol);
                portfolio.push({
                    id: Date.now() + index,
                    symbol: stock.symbol,
                    shares: stock.shares,
                    purchasePrice: stock.purchasePrice,
                    currentPrice: currentPrice,
                    dateAdded: new Date().toISOString()
                });
                savePortfolio();
                updatePortfolioDisplay();
            }, index * 1000);
        });
    }
}

// Keyboard shortcuts
document.addEventListener('keydown', function(e) {
    // Ctrl + Alt + S to add sample data
    if (e.ctrlKey && e.altKey && e.key === 's') {
        addSampleData();
    }
    
    // Escape to close modal
    if (e.key === 'Escape') {
        const modal = document.getElementById('stockModal');
        if (modal.style.display === 'block') {
            modal.style.display = 'none';
            document.body.style.overflow = 'auto';
        }
    }
});

// Export portfolio data
function exportPortfolio() {
    const dataStr = JSON.stringify(portfolio, null, 2);
    const dataBlob = new Blob([dataStr], {type: 'application/json'});
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'portfolio_data.json';
    link.click();
    URL.revokeObjectURL(url);
}

// Performance tracking
const performanceTracker = {
    startTime: Date.now(),
    
    trackPageLoad() {
        window.addEventListener('load', () => {
            const loadTime = Date.now() - this.startTime;
            console.log(`Page loaded in ${loadTime}ms`);
        });
    }
};

performanceTracker.trackPageLoad();
