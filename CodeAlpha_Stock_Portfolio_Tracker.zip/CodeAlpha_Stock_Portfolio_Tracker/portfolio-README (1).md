# Maira Atif - Stock Portfolio Website

A comprehensive personal portfolio website with integrated stock portfolio tracking functionality. This project combines professional portfolio presentation with real-time stock investment tracking tools.

## 🌟 Features

### Personal Portfolio
- **Professional Profile**: Showcasing Maira Atif as a Financial Analyst & Portfolio Manager
- **Skills Showcase**: Financial analysis, portfolio management, data analytics expertise
- **Project Gallery**: Displays financial and investment-related projects
- **Contact Form**: Professional contact interface with validation
- **Responsive Design**: Works seamlessly on all devices

### Stock Portfolio Tracker
- **Add Stocks**: Easy form to add stocks with symbol, shares, and purchase price
- **Real-time Updates**: Simulated live stock price updates (every 30 seconds)
- **Portfolio Summary**: Total investment, current value, gains/losses
- **Performance Metrics**: Daily changes, percentage gains, portfolio statistics
- **Data Persistence**: Automatically saves portfolio data to browser storage
- **Visual Feedback**: Color-coded gains (green) and losses (red)
- **Delete Functionality**: Remove stocks from portfolio with confirmation

## 🚀 Technologies Used

- **HTML5**: Semantic structure and accessibility
- **CSS3**: Modern styling with Grid, Flexbox, and animations
- **JavaScript**: Interactive functionality and portfolio management
- **Local Storage**: Data persistence without backend
- **Font Awesome**: Professional icons
- **Google Fonts**: Inter font family for clean typography

## 📁 File Structure

```
portfolio-website/
├── portfolio-index.html     # Main HTML file
├── portfolio-styles.css     # Complete CSS styling
├── portfolio-script.js      # JavaScript functionality
└── README.md               # Project documentation
```

## 🛠️ Setup Instructions

1. **Download Files**: Save all three files to the same directory
2. **Open Website**: Double-click `portfolio-index.html` or open in any web browser
3. **No Server Required**: Runs entirely in the browser using client-side technologies

## 💼 How to Use the Stock Tracker

### Adding Stocks
1. Navigate to the "Stock Portfolio" section
2. Fill in the form with:
   - Stock Symbol (e.g., AAPL, GOOGL, MSFT)
   - Number of shares owned
   - Purchase price per share
3. Click "Add Stock" button
4. Stock will appear in your portfolio table

### Viewing Performance
- **Hero Section**: Quick overview of total value, daily change, and stock count
- **Portfolio Summary**: Detailed breakdown of investment vs. current value
- **Stock Table**: Individual stock performance with gains/losses
- **Auto-Updates**: Prices update automatically every 30 seconds

### Managing Portfolio
- **Delete Stocks**: Click the trash icon to remove stocks
- **Data Persistence**: Portfolio automatically saves to browser
- **Sample Data**: Press `Ctrl + Alt + S` to add sample stocks for testing

## 🎨 Design Features

### Color Scheme
- **Primary Green**: #059669 (financial/money theme)
- **Accent Gold**: #fbbf24 (highlight color)
- **Professional Grays**: Various shades for text and backgrounds
- **Status Colors**: Green for gains, red for losses

### Layout
- **Mobile-First**: Responsive design starting from mobile
- **Grid System**: CSS Grid for complex layouts
- **Flexbox**: For alignment and distribution
- **Modern Cards**: Clean card-based interface

### Animations
- **Smooth Scrolling**: Navigate sections smoothly
- **Hover Effects**: Interactive feedback on buttons and cards
- **Fade Animations**: Elements animate in when scrolled into view
- **Loading States**: Visual feedback during data operations

## 📊 Stock Price Simulation

Since this is a demo project, stock prices are simulated using:
- **Base Prices**: Realistic starting prices for major stocks
- **Random Variation**: ±5% price fluctuation for realism
- **Auto Updates**: Prices refresh every 30 seconds
- **Popular Stocks**: Pre-configured prices for AAPL, GOOGL, MSFT, etc.

### Real API Integration
To use real stock data, replace the `getCurrentStockPrice()` function with calls to:
- **Alpha Vantage API**
- **IEX Cloud**
- **Yahoo Finance API**
- **Financial Modeling Prep API**

## 🔧 Customization

### Personal Information
Update the following in `portfolio-index.html`:
- Name and title in hero section
- Contact information
- Skills and experience
- Project descriptions
- Social media links

### Styling
Modify `portfolio-styles.css` to change:
- Color scheme
- Fonts and typography
- Layout and spacing
- Animations and effects

### Functionality
Extend `portfolio-script.js` to add:
- Real API integration
- Additional portfolio metrics
- Charts and graphs
- Export/import functionality

## 📱 Browser Compatibility

- **Chrome**: Full support
- **Firefox**: Full support
- **Safari**: Full support
- **Edge**: Full support
- **Mobile Browsers**: Responsive design works on all mobile browsers

## 🔒 Data Storage

- **Local Storage**: Portfolio data stored in browser
- **No Backend**: Completely client-side application
- **Privacy**: Data never leaves your browser
- **Persistence**: Data survives browser restarts

## 🚀 Performance

- **Fast Loading**: Optimized CSS and JavaScript
- **Smooth Animations**: 60fps animations using CSS transforms
- **Efficient Updates**: Only updates DOM when necessary
- **Responsive**: Minimal layout shifts during interactions

## 📝 Future Enhancements

- **Real-time API**: Integration with live stock data
- **Charts**: Visual charts for portfolio performance
- **Historical Data**: Track portfolio performance over time
- **Multiple Portfolios**: Support for different investment accounts
- **Export/Import**: CSV and JSON data export
- **Notifications**: Price alerts and portfolio updates
- **Advanced Analytics**: Risk metrics, beta calculations, etc.

## 👩‍💼 About Maira Atif

This portfolio website represents Maira Atif as a skilled Financial Analyst and Portfolio Manager with expertise in:

- **Financial Analysis**: Deep understanding of market trends and analysis
- **Portfolio Management**: Professional investment portfolio oversight
- **Data Analytics**: Data-driven investment decision making
- **Technology Integration**: Modern tools for financial management

## 📞 Contact

For questions about this project or to connect with Maira Atif:

- **Email**: maira.atif@email.com
- **Phone**: +92 (300) 123-4567
- **Location**: Karachi, Pakistan

## 📄 License

This project is created for educational and portfolio demonstration purposes. Feel free to use as a template for your own portfolio website.

---

**Built with ❤️ for modern financial professionals**
