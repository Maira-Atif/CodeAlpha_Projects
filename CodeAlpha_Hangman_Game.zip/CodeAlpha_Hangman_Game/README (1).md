# Hangman Game

A classic word-guessing game implemented in Python. Try to guess the hidden word by suggesting letters within a limited number of guesses.

## How to Play

1. The game randomly selects a word from a predefined list
2. You see blank spaces representing each letter in the word
3. Guess letters one at a time
4. Correct guesses reveal the letter's position(s) in the word
5. Wrong guesses add parts to the hangman drawing
6. Win by guessing all letters before the drawing is complete
7. You have 6 wrong guesses before losing

## Features

- Visual hangman drawing that updates with each wrong guess
- Input validation to ensure only single letters are accepted
- Tracks previously guessed letters
- Option to play multiple rounds
- Clear display of game progress
- Cross-platform screen clearing

## Requirements

- Python 3.6 or higher
- No additional packages required (uses only standard library)

## Installation

1. Download the `hangman_game.py` file
2. Make sure Python is installed on your system
3. No additional setup required!

## Running the Game

### Windows
```bash
python hangman_game.py
```

### Linux/Mac
```bash
python3 hangman_game.py
```

## Game Rules

- Enter one letter at a time when prompted
- Letters are case-insensitive (automatically converted to uppercase)
- You cannot guess the same letter twice
- The game ends when you either:
  - Guess all letters correctly (you win!)
  - Make 6 incorrect guesses (you lose!)

## Word List

The game includes 20 words related to programming and technology:
- python, javascript, computer, programming, developer
- keyboard, monitor, software, hardware, internet
- database, algorithm, function, variable, debugging
- challenge, creative, solution, problem, thinking

You can easily modify the `WORD_LIST` in the code to add your own words.

## Game Controls

- `Ctrl+C` - Quit the game at any time
- `y/yes` - Play another round
- `n/no` - Exit the game

## Example Gameplay

```
==================================================
         WELCOME TO HANGMAN!
==================================================
Try to guess the word letter by letter.
You have 6 wrong guesses allowed.

           --------
           |      |
           |      
           |      
           |      
           |      
        --------

Word: _ _ _ _ _ _
Wrong guesses left: 6

Enter a letter: p
Good job! 'P' is in the word.

Word: P _ _ _ _ _
Wrong guesses left: 6
Letters guessed: P

Enter a letter: y
Good job! 'Y' is in the word.
```

## Customization

To add more words, edit the `WORD_LIST` variable in the code:

```python
WORD_LIST = [
    "python", "javascript", "computer",
    # Add your words here
    "newword", "anotherword"
]
```

## Troubleshooting

**Game doesn't start:**
- Make sure Python is properly installed
- Try running with `python3` instead of `python`

**Input not working:**
- Ensure you're running in a proper terminal/command prompt
- Avoid using IDE run buttons that don't support interactive input

**Screen doesn't clear:**
- This is normal on some systems and doesn't affect gameplay

## Author

Created as a fun programming exercise demonstrating basic Python concepts like loops, conditionals, functions, and user input handling.

## License

This is a simple educational project - feel free to use, modify, and share!
