#!/usr/bin/env python3
"""
Simple Hangman Game
A classic word guessing game implemented in Python
"""

import random
import os

# Word bank - feel free to add more words!
WORD_LIST = [
    "python", "javascript", "computer", "programming", "developer",
    "keyboard", "monitor", "software", "hardware", "internet",
    "database", "algorithm", "function", "variable", "debugging",
    "challenge", "creative", "solution", "problem", "thinking"
]

def clear_screen():
    """Clear the terminal screen"""
    os.system('cls' if os.name == 'nt' else 'clear')

def display_hangman(wrong_guesses):
    """Show hangman figure based on wrong guesses"""
    stages = [
        """
           --------
           |      |
           |      
           |      
           |      
           |      
        --------
        """,
        """
           --------
           |      |
           |      O
           |      
           |      
           |      
        --------
        """,
        """
           --------
           |      |
           |      O
           |      |
           |      
           |      
        --------
        """,
        """
           --------
           |      |
           |      O
           |     /|
           |      
           |      
        --------
        """,
        """
           --------
           |      |
           |      O
           |     /|\\
           |      
           |      
        --------
        """,
        """
           --------
           |      |
           |      O
           |     /|\\
           |     / 
           |      
        --------
        """,
        """
           --------
           |      |
           |      O
           |     /|\\
           |     / \\
           |      
        --------
        """
    ]
    return stages[wrong_guesses]

def get_word():
    """Pick a random word from the list"""
    return random.choice(WORD_LIST).upper()

def display_word(word, guessed_letters):
    """Show the word with guessed letters revealed"""
    result = ""
    for letter in word:
        if letter in guessed_letters:
            result += letter + " "
        else:
            result += "_ "
    return result.strip()

def get_player_guess(guessed_letters):
    """Get a valid letter guess from player"""
    while True:
        guess = input("\nEnter a letter: ").upper().strip()
        
        if len(guess) != 1:
            print("Please enter only one letter!")
            continue
            
        if not guess.isalpha():
            print("Please enter a valid letter!")
            continue
            
        if guess in guessed_letters:
            print("You already guessed that letter!")
            continue
            
        return guess

def play_hangman():
    """Main game logic"""
    word = get_word()
    guessed_letters = set()
    wrong_guesses = 0
    max_wrong = 6
    
    print("=" * 50)
    print("         WELCOME TO HANGMAN!")
    print("=" * 50)
    print("Try to guess the word letter by letter.")
    print(f"You have {max_wrong} wrong guesses allowed.")
    print()
    
    # Main game loop
    while wrong_guesses < max_wrong:
        # Show current game state
        print(display_hangman(wrong_guesses))
        print(f"Word: {display_word(word, guessed_letters)}")
        print(f"Wrong guesses left: {max_wrong - wrong_guesses}")
        
        if guessed_letters:
            print(f"Letters guessed: {', '.join(sorted(guessed_letters))}")
        
        # Check if player won
        if all(letter in guessed_letters for letter in word):
            print(f"\n🎉 Congratulations! You guessed the word: {word}")
            return True
            
        # Get player's guess
        guess = get_player_guess(guessed_letters)
        guessed_letters.add(guess)
        
        # Check if guess is correct
        if guess in word:
            print(f"Good job! '{guess}' is in the word.")
        else:
            wrong_guesses += 1
            print(f"Sorry! '{guess}' is not in the word.")
    
    # Game over - player lost
    print(display_hangman(wrong_guesses))
    print(f"\n💀 Game Over! The word was: {word}")
    return False

def main():
    """Main function to run the game"""
    while True:
        try:
            play_hangman()
            
            # Ask if player wants to play again
            while True:
                play_again = input("\nDo you want to play again? (y/n): ").lower().strip()
                if play_again in ['y', 'yes']:
                    clear_screen()
                    break
                elif play_again in ['n', 'no']:
                    print("Thanks for playing! Goodbye!")
                    return
                else:
                    print("Please enter 'y' for yes or 'n' for no.")
                    
        except KeyboardInterrupt:
            print("\n\nGame interrupted. Thanks for playing!")
            break
        except Exception as e:
            print(f"An error occurred: {e}")
            break

if __name__ == "__main__":
    main()
