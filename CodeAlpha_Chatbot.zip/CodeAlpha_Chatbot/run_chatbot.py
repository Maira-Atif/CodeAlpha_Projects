#!/usr/bin/env python3
"""
Chatbot Launcher - Easy way to run different chatbot implementations
"""

import os
import sys

def display_menu():
    """Display the chatbot selection menu"""
    print("=" * 60)
    print("🤖 CHATBOT PROJECT LAUNCHER")
    print("=" * 60)
    print("Choose which chatbot you'd like to run:")
    print()
    print("1. Simple ChatBot (No dependencies required)")
    print("   - Basic conversation patterns")
    print("   - Name memory and sentiment detection")
    print("   - Instant startup")
    print()
    print("2. Main ChatBot (Requires NLTK, scikit-learn)")
    print("   - Natural language processing")
    print("   - Intelligent response matching")
    print("   - Sentiment analysis")
    print()
    print("3. Advanced ChatBot (Requires spaCy, NLTK)")
    print("   - Named entity recognition")
    print("   - Topic detection and memory")
    print("   - Grammar analysis")
    print()
    print("4. Exit")
    print("=" * 60)

def check_dependencies():
    """Check if dependencies are installed"""
    dependencies = {
        'main': ['nltk', 'sklearn', 'textblob'],
        'advanced': ['spacy', 'nltk', 'textblob']
    }
    
    available = {'main': True, 'advanced': True}
    
    for bot_type, deps in dependencies.items():
        for dep in deps:
            try:
                __import__(dep)
            except ImportError:
                available[bot_type] = False
                break
    
    return available

def run_simple_chatbot():
    """Run the simple chatbot"""
    try:
        from simple_chatbot import main
        print("\n🚀 Starting Simple ChatBot...")
        main()
    except Exception as e:
        print(f"❌ Error running simple chatbot: {e}")

def run_main_chatbot():
    """Run the main chatbot"""
    try:
        from chatbot import main
        print("\n🚀 Starting Main ChatBot...")
        main()
    except ImportError as e:
        print(f"❌ Missing dependencies for main chatbot: {e}")
        print("💡 Install with: pip install -r requirements.txt")
    except Exception as e:
        print(f"❌ Error running main chatbot: {e}")

def run_advanced_chatbot():
    """Run the advanced chatbot"""
    try:
        from advanced_chatbot import main
        print("\n🚀 Starting Advanced ChatBot...")
        main()
    except ImportError as e:
        print(f"❌ Missing dependencies for advanced chatbot: {e}")
        print("💡 Install with: pip install -r requirements.txt")
        print("💡 Also run: python -m spacy download en_core_web_sm")
    except Exception as e:
        print(f"❌ Error running advanced chatbot: {e}")

def main():
    """Main launcher function"""
    # Check available dependencies
    available_bots = check_dependencies()
    
    while True:
        display_menu()
        
        # Add dependency warnings
        if not available_bots['main']:
            print("⚠️  Main ChatBot: Missing dependencies (NLTK, scikit-learn)")
        if not available_bots['advanced']:
            print("⚠️  Advanced ChatBot: Missing dependencies (spaCy, NLTK)")
        
        try:
            choice = input("\nEnter your choice (1-4): ").strip()
            
            if choice == '1':
                run_simple_chatbot()
            elif choice == '2':
                if available_bots['main']:
                    run_main_chatbot()
                else:
                    print("❌ Cannot run Main ChatBot - missing dependencies")
                    print("💡 Install with: pip install -r requirements.txt")
            elif choice == '3':
                if available_bots['advanced']:
                    run_advanced_chatbot()
                else:
                    print("❌ Cannot run Advanced ChatBot - missing dependencies")
                    print("💡 Install with: pip install -r requirements.txt")
                    print("💡 Also run: python -m spacy download en_core_web_sm")
            elif choice == '4':
                print("👋 Thanks for using the Chatbot Project! Goodbye!")
                break
            else:
                print("❌ Invalid choice. Please enter 1, 2, 3, or 4.")
            
            # Ask if user wants to run another chatbot
            if choice in ['1', '2', '3']:
                print("\n" + "=" * 60)
                continue_choice = input("Would you like to run another chatbot? (y/n): ").strip().lower()
                if continue_choice not in ['y', 'yes']:
                    print("👋 Thanks for using the Chatbot Project! Goodbye!")
                    break
                    
        except KeyboardInterrupt:
            print("\n👋 Thanks for using the Chatbot Project! Goodbye!")
            break
        except Exception as e:
            print(f"❌ An error occurred: {e}")

if __name__ == "__main__":
    main()
