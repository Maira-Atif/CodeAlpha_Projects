import random
import string
import warnings
import re

# Try to import optional NLP libraries
try:
    import nltk
    NLTK_AVAILABLE = True
except ImportError:
    NLTK_AVAILABLE = False
    print("⚠️ NLTK not available. Some features will be limited.")

try:
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.metrics.pairwise import cosine_similarity
    SKLEARN_AVAILABLE = True
except ImportError:
    SKLEARN_AVAILABLE = False
    print("⚠️ scikit-learn not available. Similarity matching disabled.")

try:
    from textblob import TextBlob
    TEXTBLOB_AVAILABLE = True
except ImportError:
    TEXTBLOB_AVAILABLE = False
    print("⚠️ TextBlob not available. Sentiment analysis will be basic.")

# Suppress warnings
warnings.filterwarnings('ignore')

class ChatBot:
    def __init__(self):
        """Initialize the chatbot with predefined responses and setup"""
        self.name = "ChatBot"
        self.responses = {
            'greeting': [
                "Hello! How can I help you today?",
                "Hi there! What's on your mind?",
                "Hey! Nice to meet you!",
                "Greetings! How are you doing?"
            ],
            'goodbye': [
                "Goodbye! Have a great day!",
                "See you later!",
                "Take care!",
                "Until next time!"
            ],
            'thanks': [
                "You're welcome!",
                "Happy to help!",
                "No problem at all!",
                "Glad I could assist!"
            ],
            'default': [
                "That's interesting! Tell me more.",
                "I see. Can you elaborate on that?",
                "Hmm, that's something to think about.",
                "Could you explain that differently?",
                "I'm not sure I understand completely. Can you rephrase?"
            ],
            'how_are_you': [
                "I'm doing well, thank you for asking!",
                "I'm great! How are you?",
                "I'm functioning perfectly! How about you?",
                "All systems are go! How are you feeling?"
            ],
            'name': [
                f"My name is {self.name}. What's yours?",
                f"I'm {self.name}! Nice to meet you!",
                f"You can call me {self.name}. What should I call you?"
            ],
            'weather': [
                "I don't have access to current weather data, but you can check your local weather app!",
                "I wish I could tell you about the weather, but I don't have that information.",
                "For weather updates, I'd recommend checking a weather website or app."
            ],
            'help': [
                "I'm here to chat with you! You can ask me questions, tell me about your day, or just have a conversation.",
                "I can help with general conversation, answer simple questions, or just listen to what you have to say!",
                "Feel free to talk about anything - I'm here to chat and help however I can!"
            ]
        }
        
        # Initialize knowledge base for more intelligent responses
        self.knowledge_base = [
            "I am a chatbot created to have conversations with users.",
            "I use natural language processing to understand and respond to messages.",
            "I can discuss various topics and try to be helpful in conversations.",
            "I learn from our conversation to provide better responses.",
            "I enjoy talking about technology, science, books, movies, and daily life.",
            "I can help with general questions and provide information on various topics."
        ]
          # Download required NLTK data
        self.setup_nltk()
        
        # Initialize vectorizer for similarity matching
        if SKLEARN_AVAILABLE:
            self.vectorizer = TfidfVectorizer(stop_words='english', lowercase=True)
        else:
            self.vectorizer = None
        
    def setup_nltk(self):
        """Download required NLTK data"""
        if not NLTK_AVAILABLE:
            return
            
        try:
            nltk.data.find('tokenizers/punkt')
        except LookupError:
            nltk.download('punkt')
        except NameError:
            pass
        
        try:
            nltk.data.find('corpora/stopwords')
        except LookupError:
            nltk.download('stopwords')
        except NameError:
            pass
            
        try:
            nltk.data.find('taggers/averaged_perceptron_tagger')
        except LookupError:
            nltk.download('averaged_perceptron_tagger')
        except NameError:
            pass
    
    def preprocess_text(self, text):
        """Clean and preprocess text"""
        # Convert to lowercase
        text = text.lower()
        # Remove punctuation
        text = text.translate(str.maketrans('', '', string.punctuation))
        # Remove extra whitespace
        text = re.sub(r'\s+', ' ', text).strip()
        return text
      def analyze_sentiment(self, text):
        """Analyze sentiment of the input text"""
        if TEXTBLOB_AVAILABLE:
            blob = TextBlob(text)
            sentiment = blob.sentiment.polarity
        else:
            # Basic sentiment analysis without TextBlob
            positive_words = ['good', 'great', 'awesome', 'excellent', 'happy', 'love', 'like', 'wonderful']
            negative_words = ['bad', 'terrible', 'awful', 'hate', 'sad', 'angry', 'frustrated', 'horrible']
            
            text_lower = text.lower()
            positive_count = sum(1 for word in positive_words if word in text_lower)
            negative_count = sum(1 for word in negative_words if word in text_lower)
            
            if positive_count > negative_count:
                sentiment = 0.5
            elif negative_count > positive_count:
                sentiment = -0.5
            else:
                sentiment = 0.0
        
        if sentiment > 0.1:
            return "positive"
        elif sentiment < -0.1:
            return "negative"
        else:
            return "neutral"
    
    def classify_intent(self, text):
        """Classify the intent of the user's message"""
        text_lower = text.lower()
        
        # Greeting patterns
        greeting_patterns = ['hello', 'hi', 'hey', 'good morning', 'good afternoon', 'good evening']
        if any(pattern in text_lower for pattern in greeting_patterns):
            return 'greeting'
        
        # Goodbye patterns
        goodbye_patterns = ['bye', 'goodbye', 'see you', 'farewell', 'exit', 'quit']
        if any(pattern in text_lower for pattern in goodbye_patterns):
            return 'goodbye'
        
        # Thanks patterns
        thanks_patterns = ['thank', 'thanks', 'appreciate']
        if any(pattern in text_lower for pattern in thanks_patterns):
            return 'thanks'
        
        # How are you patterns
        how_are_you_patterns = ['how are you', 'how do you do', 'how are things']
        if any(pattern in text_lower for pattern in how_are_you_patterns):
            return 'how_are_you'
        
        # Name patterns
        name_patterns = ['what is your name', 'who are you', 'your name']
        if any(pattern in text_lower for pattern in name_patterns):
            return 'name'
        
        # Weather patterns
        weather_patterns = ['weather', 'temperature', 'rain', 'sunny', 'cloudy']
        if any(pattern in text_lower for pattern in weather_patterns):
            return 'weather'
        
        # Help patterns
        help_patterns = ['help', 'what can you do', 'assist']
        if any(pattern in text_lower for pattern in help_patterns):
            return 'help'
        
        return 'default'
      def find_best_response(self, user_input):
        """Find the best response using similarity matching"""
        if not SKLEARN_AVAILABLE or not self.vectorizer:
            return None
            
        try:
            # Combine user input with knowledge base
            documents = self.knowledge_base + [user_input]
            
            # Create TF-IDF matrix
            tfidf_matrix = self.vectorizer.fit_transform(documents)
            
            # Calculate similarity between user input and knowledge base
            similarity_scores = cosine_similarity(tfidf_matrix[-1:], tfidf_matrix[:-1]).flatten()
            
            # Find the best match
            best_match_index = similarity_scores.argmax()
            best_score = similarity_scores[best_match_index]
            
            # If similarity is high enough, provide a contextual response
            if best_score > 0.2:
                return f"Based on what you said, I think you're interested in discussing topics related to my knowledge. {random.choice(self.responses['default'])}"
            
        except Exception as e:
            print(f"Error in similarity matching: {e}")
        
        return None
    
    def generate_response(self, user_input):
        """Generate an appropriate response to user input"""
        # Analyze sentiment
        sentiment = self.analyze_sentiment(user_input)
        
        # Classify intent
        intent = self.classify_intent(user_input)
        
        # Get base response based on intent
        if intent in self.responses:
            base_response = random.choice(self.responses[intent])
        else:
            # Try to find best response using similarity
            smart_response = self.find_best_response(user_input)
            if smart_response:
                base_response = smart_response
            else:
                base_response = random.choice(self.responses['default'])
        
        # Add sentiment-aware modifications
        if sentiment == "negative":
            empathy_phrases = [
                "I understand that might be frustrating. ",
                "I can sense that's bothering you. ",
                "That sounds challenging. "
            ]
            base_response = random.choice(empathy_phrases) + base_response
        elif sentiment == "positive":
            positive_phrases = [
                "That's great to hear! ",
                "How wonderful! ",
                "That sounds amazing! "
            ]
            base_response = random.choice(positive_phrases) + base_response
        
        return base_response
    
    def chat(self):
        """Main chat loop"""
        print(f"🤖 {self.name}: Hello! I'm your friendly chatbot. Type 'quit' to exit.")
        print("=" * 50)
        
        while True:
            try:
                user_input = input("You: ").strip()
                
                if not user_input:
                    print(f"🤖 {self.name}: I didn't catch that. Could you say something?")
                    continue
                
                if user_input.lower() in ['quit', 'exit', 'bye']:
                    print(f"🤖 {self.name}: {random.choice(self.responses['goodbye'])}")
                    break
                
                response = self.generate_response(user_input)
                print(f"🤖 {self.name}: {response}")
                
            except KeyboardInterrupt:
                print(f"\n🤖 {self.name}: Goodbye! Thanks for chatting with me!")
                break
            except Exception as e:
                print(f"🤖 {self.name}: Sorry, I encountered an error. Let's keep chatting!")

def main():
    """Main function to run the chatbot"""
    print("Initializing ChatBot...")
    print("Loading natural language processing components...")
    
    bot = ChatBot()
    bot.chat()

if __name__ == "__main__":
    main()
