# Chatbot Project

A comprehensive text-based chatbot project with multiple implementations, from simple pattern matching to advanced natural language processing capabilities.

## Project Structure

```
chatbot-project/
├── chatbot.py              # Main chatbot with NLTK and scikit-learn
├── advanced_chatbot.py     # Advanced chatbot with spaCy integration
├── simple_chatbot.py       # Simple chatbot (no external dependencies)
├── requirements.txt        # Python dependencies
├── README.md              # This file
└── run_chatbot.py         # Easy launcher script
```

## Features

### Simple Chatbot (`simple_chatbot.py`)
- **No external dependencies** - runs with just Python
- Pattern-based response matching
- Name recognition and memory
- Basic sentiment analysis
- Conversation starters
- Personalized responses

### Main Chatbot (`chatbot.py`)
- **NLTK integration** for natural language processing
- **TF-IDF vectorization** for intelligent response matching
- **Sentiment analysis** using TextBlob
- **Intent classification** for better conversation flow
- **Knowledge base** for contextual responses
- **Cosine similarity** for finding relevant responses

### Advanced Chatbot (`advanced_chatbot.py`)
- **spaCy integration** for advanced NLP
- **Named entity recognition** (NER)
- **Part-of-speech tagging**
- **Conversation history** and context awareness
- **Topic detection** and categorization
- **User preference memory**
- **Grammar analysis** capabilities

## Installation

1. **Clone or download this project**

2. **Install dependencies** (for main and advanced chatbots):
   ```bash
   pip install -r requirements.txt
   ```

3. **Download spaCy model** (for advanced chatbot):
   ```bash
   python -m spacy download en_core_web_sm
   ```

## Usage

### Quick Start (Simple Chatbot)
No installation required - just run:
```bash
python simple_chatbot.py
```

### Main Chatbot
```bash
python chatbot.py
```

### Advanced Chatbot
```bash
python advanced_chatbot.py
```

### Using the Launcher
```bash
python run_chatbot.py
```

## Chatbot Capabilities

### Conversation Features
- **Greeting recognition**: Responds to hello, hi, good morning, etc.
- **Name memory**: Remembers and uses your name in conversation
- **Sentiment awareness**: Adapts responses based on emotional tone
- **Topic detection**: Identifies and discusses various topics
- **Context awareness**: Maintains conversation flow and history

### Supported Topics
- Science and research
- Technology and programming
- Movies and entertainment
- Books and literature
- Music and arts
- Weather and daily life
- Personal feelings and emotions

### Special Commands
- Type `quit`, `exit`, or `bye` to end conversation
- Type `analyze` (in advanced chatbot) to see NLP analysis of your last message
- Ask about time/date for current information
- Ask for help to learn about capabilities

## Example Conversations

### Simple Interaction
```
You: Hello there!
🤖 SimpleBot: Hi there! How are you doing today?

You: My name is Alex
🤖 SimpleBot: Nice to meet you, Alex!

You: How are you?
🤖 SimpleBot: I'm doing great, thank you for asking! How about you Alex!
```

### Advanced Interaction
```
You: I'm feeling excited about the new AI developments
🤖 AdvancedBot: How wonderful! I see you're interested in technology! I'm interested in AI, machine learning, and software development. I noticed you mentioned AI.

You: analyze
🤖 AdvancedBot: Analysis of your last message:
   📊 Sentiment: 0.35 (polarity), 0.65 (subjectivity)
   🏷️  Topics detected: technology
   🎯 Entities found: AI (ORG)
```

## Technical Details

### Dependencies
- **nltk**: Natural language processing toolkit
- **spacy**: Advanced NLP library
- **scikit-learn**: Machine learning for text analysis
- **textblob**: Simple text processing
- **numpy**: Numerical computing
- **pandas**: Data manipulation

### Key Algorithms
- **TF-IDF Vectorization**: For finding relevant responses
- **Cosine Similarity**: For matching user input to knowledge base
- **Named Entity Recognition**: For extracting important information
- **Sentiment Analysis**: For understanding emotional context
- **Pattern Matching**: For intent classification

## Customization

### Adding New Responses
Edit the response dictionaries in each chatbot file:
```python
self.responses = {
    'new_category': [
        "Response 1",
        "Response 2",
        "Response 3"
    ]
}
```

### Adding New Topics
Extend the knowledge base:
```python
self.knowledge_base = {
    'new_topic': [
        "Information about the topic",
        "Related response",
        "Follow-up question"
    ]
}
```

### Modifying Patterns
Update pattern matching rules:
```python
'new_intent': {
    'patterns': [r'pattern1', r'pattern2'],
    'responses': ["Response 1", "Response 2"]
}
```

## Troubleshooting

### Common Issues

1. **Import errors for NLTK/spaCy**:
   - Make sure you've installed requirements: `pip install -r requirements.txt`
   - Download NLTK data: The chatbot will do this automatically on first run

2. **spaCy model not found**:
   - Download the English model: `python -m spacy download en_core_web_sm`

3. **Simple chatbot only**:
   - If you don't want to install dependencies, use `simple_chatbot.py`

### Performance Tips
- The simple chatbot starts instantly
- Main chatbot takes a few seconds to load NLTK components
- Advanced chatbot takes longer due to spaCy model loading

## Contributing

Feel free to enhance the chatbot by:
- Adding more conversation patterns
- Implementing new NLP features
- Improving response quality
- Adding new topics to the knowledge base
- Creating specialized chatbot variants

## License

This project is open source and available under the MIT License.

## Future Enhancements

Potential improvements:
- Web interface using Flask/Django
- Voice input/output capabilities
- Integration with external APIs (weather, news, etc.)
- Machine learning model training on conversations
- Multi-language support
- Personality customization
- Database storage for persistent memory
