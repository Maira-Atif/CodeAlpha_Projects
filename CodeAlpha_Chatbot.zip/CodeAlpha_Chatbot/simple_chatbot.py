import random
import re
import json
import datetime
from typing import Dict, List, Tuple

class SimpleChatBot:
    """A simple chatbot that doesn't require external libraries"""
    
    def __init__(self):
        self.name = "SimpleBot"
        self.conversation_count = 0
        self.user_name = None
        self.conversation_history = []
        
        # Response patterns and templates
        self.patterns = {
            'greeting': {
                'patterns': [r'hello', r'hi', r'hey', r'good (morning|afternoon|evening)', r'greetings'],
                'responses': [
                    "Hello! Nice to meet you!",
                    "Hi there! How are you doing today?",
                    "Hey! What's on your mind?",
                    "Greetings! I'm here to chat with you."
                ]
            },
            'name_ask': {
                'patterns': [r'what.*your name', r'who are you', r'what.*called'],
                'responses': [
                    f"I'm {self.name}, your friendly chatbot! What's your name?",
                    f"My name is {self.name}. I'm here to chat with you!",
                    f"You can call me {self.name}. What should I call you?"
                ]
            },
            'name_tell': {
                'patterns': [r'my name is (\w+)', r'i am (\w+)', r'call me (\w+)', r'i\'m (\w+)'],
                'responses': [
                    "Nice to meet you, {name}!",
                    "Hello {name}! Great to know your name.",
                    "Thanks for telling me, {name}! How can I help you today?"
                ]
            },
            'how_are_you': {
                'patterns': [r'how are you', r'how.*doing', r'what.*up'],
                'responses': [
                    "I'm doing great, thank you for asking! How about you?",
                    "I'm functioning perfectly! How are you feeling today?",
                    "All good here! What brings you to chat with me?"
                ]
            },
            'goodbye': {
                'patterns': [r'bye', r'goodbye', r'see you', r'farewell', r'exit', r'quit'],
                'responses': [
                    "Goodbye! It was nice chatting with you!",
                    "See you later! Have a wonderful day!",
                    "Take care! Thanks for the great conversation!",
                    "Until next time! Stay safe!"
                ]
            },
            'thanks': {
                'patterns': [r'thank.*you', r'thanks', r'appreciate'],
                'responses': [
                    "You're very welcome!",
                    "Happy to help!",
                    "No problem at all!",
                    "Glad I could assist you!"
                ]
            },
            'weather': {
                'patterns': [r'weather', r'rain', r'sunny', r'cloudy', r'temperature'],
                'responses': [
                    "I don't have access to current weather data, but I hope it's nice where you are!",
                    "I wish I could check the weather for you! Maybe try a weather app?",
                    "Weather can really affect our mood. How's it looking outside?"
                ]
            },
            'time': {
                'patterns': [r'what.*time', r'current time', r'what.*date'],
                'responses': [
                    f"The current time is {datetime.datetime.now().strftime('%H:%M')}",
                    f"Today is {datetime.datetime.now().strftime('%B %d, %Y')}",
                    f"Right now it's {datetime.datetime.now().strftime('%I:%M %p')}"
                ]
            },
            'help': {
                'patterns': [r'help', r'what.*can.*do', r'assist', r'support'],
                'responses': [
                    "I'm here to chat with you! You can ask me questions, tell me about your day, or just have a conversation.",
                    "I can help with basic conversation, tell you the time, or just listen to what you want to share!",
                    "Feel free to talk about anything - I'm here to be your conversation partner!"
                ]
            },
            'feelings': {
                'patterns': [r'i.*feel.*sad', r'i.*feel.*happy', r'i.*feel.*angry', r'i.*depressed', r'i.*excited'],
                'responses': [
                    "I hear you. Sometimes it helps to talk about how we're feeling.",
                    "Thanks for sharing that with me. Emotions are important to acknowledge.",
                    "I appreciate you being open about your feelings. How can I support you?"
                ]
            },
            'compliment': {
                'patterns': [r'you.*great', r'you.*awesome', r'you.*good', r'you.*smart'],
                'responses': [
                    "Thank you so much! That's very kind of you to say.",
                    "I appreciate the compliment! You're pretty awesome yourself!",
                    "That means a lot to me. Thanks for being so nice!"
                ]
            }
        }
        
        # Default responses when no pattern matches
        self.default_responses = [
            "That's interesting! Tell me more about that.",
            "I see. Can you elaborate on that?",
            "Hmm, that's something to think about. What's your perspective?",
            "Could you help me understand that better?",
            "That sounds intriguing. What made you think of that?",
            "I'm listening. Please continue.",
            "That's a good point. What else is on your mind?"
        ]
        
        # Conversation starters for when things get quiet
        self.conversation_starters = [
            "What's something that made you smile today?",
            "Do you have any hobbies or interests you're passionate about?",
            "What's your favorite way to spend free time?",
            "Have you learned anything interesting recently?",
            "What's something you're looking forward to?"
        ]
    
    def preprocess_input(self, text: str) -> str:
        """Clean and prepare user input for processing"""
        # Convert to lowercase and strip whitespace
        text = text.lower().strip()
        # Remove extra spaces
        text = re.sub(r'\s+', ' ', text)
        return text
    
    def extract_name(self, text: str) -> str:
        """Extract name from user input"""
        # Look for name patterns
        name_patterns = [
            r'my name is (\w+)',
            r'i am (\w+)',
            r'call me (\w+)',
            r'i\'m (\w+)'
        ]
        
        for pattern in name_patterns:
            match = re.search(pattern, text.lower())
            if match:
                return match.group(1).capitalize()
        return None
    
    def detect_sentiment(self, text: str) -> str:
        """Simple sentiment detection based on keywords"""
        positive_words = ['happy', 'good', 'great', 'awesome', 'excellent', 'wonderful', 'amazing', 'love', 'like']
        negative_words = ['sad', 'bad', 'terrible', 'awful', 'hate', 'angry', 'frustrated', 'upset', 'disappointed']
        
        text_lower = text.lower()
        positive_count = sum(1 for word in positive_words if word in text_lower)
        negative_count = sum(1 for word in negative_words if word in text_lower)
        
        if positive_count > negative_count:
            return 'positive'
        elif negative_count > positive_count:
            return 'negative'
        else:
            return 'neutral'
    
    def find_pattern_match(self, text: str) -> Tuple[str, str, str]:
        """Find matching pattern and return category, matched text, and response"""
        text_processed = self.preprocess_input(text)
        
        for category, data in self.patterns.items():
            for pattern in data['patterns']:
                match = re.search(pattern, text_processed)
                if match:
                    response_template = random.choice(data['responses'])
                    
                    # Handle name extraction for name_tell pattern
                    if category == 'name_tell':
                        name = self.extract_name(text)
                        if name:
                            self.user_name = name
                            response = response_template.format(name=name)
                        else:
                            response = response_template
                    else:
                        response = response_template
                    
                    return category, match.group(0), response
        
        return None, None, None
    
    def generate_response(self, user_input: str) -> str:
        """Generate appropriate response to user input"""
        # Try to find pattern match
        category, matched_text, response = self.find_pattern_match(user_input)
        
        if response:
            # Add personalization if we know the user's name
            if self.user_name and category not in ['name_tell', 'name_ask']:
                if random.random() < 0.3:  # 30% chance to use name
                    response = f"{response.rstrip('.')} {self.user_name}!"
            return response
        
        # No pattern matched, use default response
        sentiment = self.detect_sentiment(user_input)
        default_response = random.choice(self.default_responses)
        
        # Modify response based on sentiment
        if sentiment == 'positive':
            positive_prefixes = ["That sounds great! ", "How wonderful! ", "I love your enthusiasm! "]
            default_response = random.choice(positive_prefixes) + default_response
        elif sentiment == 'negative':
            empathy_prefixes = ["I understand. ", "That sounds challenging. ", "I hear you. "]
            default_response = random.choice(empathy_prefixes) + default_response
        
        return default_response
    
    def should_ask_conversation_starter(self) -> bool:
        """Determine if we should ask a conversation starter"""
        return (
            len(self.conversation_history) > 0 and 
            len(self.conversation_history) % 5 == 0 and
            random.random() < 0.4
        )
    
    def chat(self):
        """Main chat loop"""
        print(f"🤖 {self.name}: Hello! I'm a simple but friendly chatbot.")
        print("I can have conversations, remember your name, and respond to various topics.")
        print("Type 'quit', 'exit', or 'bye' to end our conversation.")
        print("=" * 60)
        
        while True:
            try:
                user_input = input("You: ").strip()
                
                if not user_input:
                    print(f"🤖 {self.name}: I'm here when you're ready to chat!")
                    continue
                
                # Check for exit commands
                if any(word in user_input.lower() for word in ['quit', 'exit', 'bye', 'goodbye']):
                    farewell_response = self.generate_response(user_input)
                    print(f"🤖 {self.name}: {farewell_response}")
                    if self.user_name:
                        print(f"🤖 {self.name}: It was really nice getting to know you, {self.user_name}!")
                    break
                
                # Store conversation
                self.conversation_history.append(user_input)
                self.conversation_count += 1
                
                # Generate and display response
                response = self.generate_response(user_input)
                print(f"🤖 {self.name}: {response}")
                
                # Occasionally ask conversation starters
                if self.should_ask_conversation_starter():
                    starter = random.choice(self.conversation_starters)
                    print(f"🤖 {self.name}: {starter}")
                
            except KeyboardInterrupt:
                print(f"\n🤖 {self.name}: Thanks for chatting with me! Take care!")
                break
            except Exception as e:
                print(f"🤖 {self.name}: Oops, something went wrong, but I'm still here to chat!")

def main():
    """Run the simple chatbot"""
    print("Starting Simple ChatBot (no external libraries required)...")
    bot = SimpleChatBot()
    bot.chat()

if __name__ == "__main__":
    main()
