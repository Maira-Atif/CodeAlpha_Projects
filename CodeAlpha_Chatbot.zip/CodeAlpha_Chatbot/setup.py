#!/usr/bin/env python3
"""
Setup script for the Chatbot Project
"""

import subprocess
import sys
import os

def install_requirements():
    """Install required packages"""
    print("📦 Installing required packages...")
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
        print("✅ Successfully installed packages!")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Failed to install packages: {e}")
        return False

def download_spacy_model():
    """Download spaCy English model"""
    print("🔽 Downloading spaCy English model...")
    try:
        subprocess.check_call([sys.executable, "-m", "spacy", "download", "en_core_web_sm"])
        print("✅ Successfully downloaded spaCy model!")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Failed to download spaCy model: {e}")
        print("💡 You can run this manually: python -m spacy download en_core_web_sm")
        return False

def test_imports():
    """Test if all imports work"""
    print("🧪 Testing imports...")
    
    # Test simple chatbot (should always work)
    try:
        import datetime
        import random
        import re
        print("✅ Simple chatbot dependencies: OK")
    except ImportError as e:
        print(f"❌ Simple chatbot dependencies: {e}")
    
    # Test main chatbot
    try:
        import nltk
        import sklearn
        import textblob
        print("✅ Main chatbot dependencies: OK")
    except ImportError as e:
        print(f"❌ Main chatbot dependencies: {e}")
    
    # Test advanced chatbot
    try:
        import spacy
        nlp = spacy.load("en_core_web_sm")
        print("✅ Advanced chatbot dependencies: OK")
    except ImportError as e:
        print(f"❌ Advanced chatbot dependencies: {e}")
    except OSError as e:
        print(f"⚠️  Advanced chatbot: spaCy model not found - {e}")

def main():
    """Main setup function"""
    print("🤖 CHATBOT PROJECT SETUP")
    print("=" * 40)
    
    print("\nThis script will help you set up the chatbot project.")
    print("Choose what you want to install:")
    print("\n1. Install all dependencies (recommended)")
    print("2. Install basic dependencies only (main chatbot)")
    print("3. Test current installation")
    print("4. Skip setup (use simple chatbot only)")
    
    choice = input("\nEnter your choice (1-4): ").strip()
    
    if choice == '1':
        print("\n🚀 Installing all dependencies...")
        if install_requirements():
            download_spacy_model()
        test_imports()
        
    elif choice == '2':
        print("\n🚀 Installing basic dependencies...")
        # Create minimal requirements file
        with open('requirements_basic.txt', 'w') as f:
            f.write("nltk==3.8.1\nscikit-learn==1.3.2\ntextblob==0.17.1\nnumpy==1.24.3\n")
        
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements_basic.txt"])
            print("✅ Basic dependencies installed!")
        except subprocess.CalledProcessError as e:
            print(f"❌ Failed to install basic dependencies: {e}")
        
        test_imports()
        
    elif choice == '3':
        test_imports()
        
    elif choice == '4':
        print("\n✅ No setup needed for simple chatbot!")
        print("You can run: python simple_chatbot.py")
        
    else:
        print("❌ Invalid choice")
        return
    
    print("\n" + "=" * 40)
    print("🎉 Setup complete! You can now run:")
    print("   python run_chatbot.py    (launcher)")
    print("   python simple_chatbot.py (no dependencies)")
    print("   python chatbot.py        (main chatbot)")
    print("   python advanced_chatbot.py (advanced features)")

if __name__ == "__main__":
    main()
