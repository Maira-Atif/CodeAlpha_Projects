import nltk
import spacy
from textblob import TextBlob
import re
from collections import defaultdict

class AdvancedChatBot:
    def __init__(self):
        """Initialize advanced chatbot with enhanced NLP capabilities"""
        self.name = "AdvancedBot"
        self.conversation_history = []
        self.user_preferences = defaultdict(list)
        self.topics_discussed = set()
        
        # Load spaCy model (using small English model)
        try:
            self.nlp = spacy.load("en_core_web_sm")
        except OSError:
            print("spaCy model not found. Please run: python -m spacy download en_core_web_sm")
            self.nlp = None
        
        # Extended knowledge base with categories
        self.knowledge_base = {
            'science': [
                "Science is fascinating! I love discussing physics, chemistry, and biology.",
                "Scientific discoveries have shaped our understanding of the world.",
                "What aspect of science interests you the most?"
            ],
            'technology': [
                "Technology is evolving rapidly these days!",
                "I'm interested in AI, machine learning, and software development.",
                "What technology trends do you find most exciting?"
            ],
            'movies': [
                "I enjoy discussing movies and their storytelling techniques.",
                "What genres do you prefer? I find sci-fi and drama particularly interesting.",
                "Have you seen any good movies lately?"
            ],
            'books': [
                "Books are wonderful for expanding our knowledge and imagination.",
                "I appreciate both fiction and non-fiction literature.",
                "What's the last book that really impressed you?"
            ],
            'music': [
                "Music has a unique way of expressing emotions and connecting people.",
                "I find it interesting how different genres evoke different feelings.",
                "What kind of music do you enjoy?"
            ]
        }
        
        self.setup_nltk()
    
    def setup_nltk(self):
        """Setup NLTK components"""
        required_data = ['punkt', 'stopwords', 'averaged_perceptron_tagger', 'wordnet']
        for data in required_data:
            try:
                nltk.data.find(f'tokenizers/{data}' if data == 'punkt' else 
                              f'corpora/{data}' if data in ['stopwords', 'wordnet'] else 
                              f'taggers/{data}')
            except LookupError:
                nltk.download(data)
    
    def extract_entities(self, text):
        """Extract named entities from text using spaCy"""
        if not self.nlp:
            return []
        
        doc = self.nlp(text)
        entities = [(ent.text, ent.label_) for ent in doc.ents]
        return entities
    
    def analyze_grammar(self, text):
        """Analyze grammar and parts of speech"""
        if not self.nlp:
            return []
        
        doc = self.nlp(text)
        analysis = []
        for token in doc:
            analysis.append({
                'text': token.text,
                'pos': token.pos_,
                'tag': token.tag_,
                'lemma': token.lemma_
            })
        return analysis
    
    def detect_topics(self, text):
        """Detect topics mentioned in the text"""
        text_lower = text.lower()
        detected_topics = []
        
        topic_keywords = {
            'science': ['science', 'physics', 'chemistry', 'biology', 'research', 'experiment'],
            'technology': ['technology', 'computer', 'software', 'ai', 'artificial intelligence', 'programming'],
            'movies': ['movie', 'film', 'cinema', 'actor', 'director', 'hollywood'],
            'books': ['book', 'novel', 'author', 'reading', 'literature', 'story'],
            'music': ['music', 'song', 'band', 'artist', 'album', 'concert']
        }
        
        for topic, keywords in topic_keywords.items():
            if any(keyword in text_lower for keyword in keywords):
                detected_topics.append(topic)
                self.topics_discussed.add(topic)
        
        return detected_topics
    
    def generate_contextual_response(self, user_input):
        """Generate response based on conversation context"""
        # Detect topics in current input
        topics = self.detect_topics(user_input)
        
        # Extract entities
        entities = self.extract_entities(user_input)
        
        # Analyze sentiment
        blob = TextBlob(user_input)
        sentiment_score = blob.sentiment.polarity
        
        response = ""
        
        # Generate topic-based response
        if topics:
            topic = topics[0]  # Focus on first detected topic
            topic_responses = self.knowledge_base.get(topic, [])
            if topic_responses:
                response = f"I see you're interested in {topic}! " + topic_responses[0]
        
        # Mention entities if found
        if entities:
            entity_text = ", ".join([ent[0] for ent in entities[:2]])  # Mention up to 2 entities
            response += f" I noticed you mentioned {entity_text}."
        
        # Add sentiment-based response
        if sentiment_score > 0.3:
            response += " You seem enthusiastic about this topic!"
        elif sentiment_score < -0.3:
            response += " I understand this might be a sensitive topic for you."
        
        # Fallback response
        if not response:
            response = "That's an interesting point. Could you tell me more about your thoughts on this?"
        
        return response
    
    def remember_user_preference(self, topic, detail):
        """Remember user preferences for personalized responses"""
        self.user_preferences[topic].append(detail)
    
    def get_personalized_response(self, topic):
        """Generate personalized response based on user's history"""
        if topic in self.user_preferences:
            return f"I remember you mentioned {topic} before. " + self.knowledge_base[topic][0]
        return self.knowledge_base[topic][0] if topic in self.knowledge_base else ""
    
    def chat(self):
        """Enhanced chat loop with advanced NLP features"""
        print(f"🤖 {self.name}: Hello! I'm an advanced chatbot with natural language understanding.")
        print("I can analyze sentiment, extract entities, and remember our conversation context.")
        print("Type 'quit' to exit, or 'analyze' to see analysis of your last message.")
        print("=" * 70)
        
        while True:
            try:
                user_input = input("You: ").strip()
                
                if not user_input:
                    continue
                
                if user_input.lower() in ['quit', 'exit']:
                    print(f"🤖 {self.name}: It was great chatting with you! We discussed: {', '.join(self.topics_discussed) if self.topics_discussed else 'various topics'}.")
                    break
                
                if user_input.lower() == 'analyze' and self.conversation_history:
                    last_message = self.conversation_history[-1]
                    entities = self.extract_entities(last_message)
                    topics = self.detect_topics(last_message)
                    sentiment = TextBlob(last_message).sentiment
                    
                    print(f"🤖 {self.name}: Analysis of your last message:")
                    print(f"   📊 Sentiment: {sentiment.polarity:.2f} (polarity), {sentiment.subjectivity:.2f} (subjectivity)")
                    print(f"   🏷️  Topics detected: {', '.join(topics) if topics else 'None'}")
                    print(f"   🎯 Entities found: {', '.join([f'{ent[0]} ({ent[1]})' for ent in entities]) if entities else 'None'}")
                    continue
                
                # Store conversation history
                self.conversation_history.append(user_input)
                
                # Generate response using advanced NLP
                response = self.generate_contextual_response(user_input)
                print(f"🤖 {self.name}: {response}")
                
            except KeyboardInterrupt:
                print(f"\n🤖 {self.name}: Goodbye! Thanks for the interesting conversation!")
                break
            except Exception as e:
                print(f"🤖 {self.name}: I encountered an error, but let's keep chatting!")

def main():
    """Run the advanced chatbot"""
    print("Loading Advanced ChatBot with NLP capabilities...")
    bot = AdvancedChatBot()
    bot.chat()

if __name__ == "__main__":
    main()
