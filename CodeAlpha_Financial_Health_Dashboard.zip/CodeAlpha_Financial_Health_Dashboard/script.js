class FinancialDashboard {
    constructor() {
        this.charts = {};
        this.financialData = {};
        this.dateRange = 6;
        this.init();
    }

    init() {
        this.loadSampleData();
        this.initializeCharts();
        this.updateLastUpdated();
        this.bindEvents();
    }

    loadSampleData() {
        this.financialData = {
            revenue: [45000, 52000, 48000, 55000, 62000, 58000],
            expenses: [38000, 42000, 41000, 46000, 51000, 47000],
            netProfit: [7000, 10000, 7000, 9000, 11000, 11000],
            cashFlow: [12000, 15000, 8000, 14000, 18000, 16000],
            months: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
            incomeStatement: {
                revenue: 350000,
                cogs: 210000,
                grossProfit: 140000,
                operatingExpenses: 85000,
                operatingIncome: 55000,
                interestExpense: 5000,
                netIncome: 50000
            },
            balanceSheet: {
                currentAssets: 180000,
                fixedAssets: 320000,
                totalAssets: 500000,
                currentLiabilities: 120000,
                longTermDebt: 180000,
                equity: 200000
            },
            cashFlowStatement: {
                operating: 65000,
                investing: -45000,
                financing: -15000,
                netCashFlow: 5000,
                beginningCash: 25000,
                endingCash: 30000
            },
            expenseBreakdown: {
                salaries: 35,
                rent: 15,
                marketing: 20,
                utilities: 8,
                supplies: 12,
                other: 10
            },
            ratios: {
                grossMargin: 40,
                netMargin: 14.3,
                roe: 25,
                roa: 10,
                currentRatio: 1.5,
                debtToEquity: 1.5
            }
        };

        this.updateMetrics();
        this.updateFinancialStatements();
        this.calculateHealthScore();
    }

    updateMetrics() {
        const currentRevenue = this.financialData.revenue[this.financialData.revenue.length - 1];
        const previousRevenue = this.financialData.revenue[this.financialData.revenue.length - 2];
        const revenueChange = ((currentRevenue - previousRevenue) / previousRevenue * 100).toFixed(1);

        const currentProfit = this.financialData.netProfit[this.financialData.netProfit.length - 1];
        const previousProfit = this.financialData.netProfit[this.financialData.netProfit.length - 2];
        const profitChange = ((currentProfit - previousProfit) / previousProfit * 100).toFixed(1);

        const currentCashFlow = this.financialData.cashFlow[this.financialData.cashFlow.length - 1];
        const previousCashFlow = this.financialData.cashFlow[this.financialData.cashFlow.length - 2];
        const cashFlowChange = ((currentCashFlow - previousCashFlow) / previousCashFlow * 100).toFixed(1);

        const profitMargin = (currentProfit / currentRevenue * 100).toFixed(1);
        const previousMargin = (previousProfit / previousRevenue * 100).toFixed(1);
        const marginChange = (profitMargin - previousMargin).toFixed(1);

        document.getElementById('totalRevenue').textContent = this.formatCurrency(currentRevenue);
        document.getElementById('revenueChange').textContent = `${revenueChange >= 0 ? '+' : ''}${revenueChange}%`;
        document.getElementById('revenueChange').className = `metric-change ${revenueChange >= 0 ? 'text-success' : 'text-danger'}`;

        document.getElementById('netProfit').textContent = this.formatCurrency(currentProfit);
        document.getElementById('profitChange').textContent = `${profitChange >= 0 ? '+' : ''}${profitChange}%`;
        document.getElementById('profitChange').className = `metric-change ${profitChange >= 0 ? 'text-success' : 'text-danger'}`;

        document.getElementById('cashFlow').textContent = this.formatCurrency(currentCashFlow);
        document.getElementById('cashFlowChange').textContent = `${cashFlowChange >= 0 ? '+' : ''}${cashFlowChange}%`;
        document.getElementById('cashFlowChange').className = `metric-change ${cashFlowChange >= 0 ? 'text-success' : 'text-danger'}`;

        document.getElementById('profitMargin').textContent = `${profitMargin}%`;
        document.getElementById('marginChange').textContent = `${marginChange >= 0 ? '+' : ''}${marginChange}%`;
        document.getElementById('marginChange').className = `metric-change ${marginChange >= 0 ? 'text-success' : 'text-danger'}`;
    }

    updateFinancialStatements() {
        const is = this.financialData.incomeStatement;
        document.getElementById('is-revenue').textContent = this.formatCurrency(is.revenue);
        document.getElementById('is-cogs').textContent = this.formatCurrency(is.cogs);
        document.getElementById('is-gross-profit').textContent = this.formatCurrency(is.grossProfit);
        document.getElementById('is-opex').textContent = this.formatCurrency(is.operatingExpenses);
        document.getElementById('is-operating-income').textContent = this.formatCurrency(is.operatingIncome);
        document.getElementById('is-interest').textContent = this.formatCurrency(is.interestExpense);
        document.getElementById('is-net-income').textContent = this.formatCurrency(is.netIncome);

        const bs = this.financialData.balanceSheet;
        document.getElementById('bs-current-assets').textContent = this.formatCurrency(bs.currentAssets);
        document.getElementById('bs-fixed-assets').textContent = this.formatCurrency(bs.fixedAssets);
        document.getElementById('bs-total-assets').textContent = this.formatCurrency(bs.totalAssets);
        document.getElementById('bs-current-liabilities').textContent = this.formatCurrency(bs.currentLiabilities);
        document.getElementById('bs-long-term-debt').textContent = this.formatCurrency(bs.longTermDebt);
        document.getElementById('bs-equity').textContent = this.formatCurrency(bs.equity);

        const cf = this.financialData.cashFlowStatement;
        document.getElementById('cf-operating').textContent = this.formatCurrency(cf.operating);
        document.getElementById('cf-investing').textContent = this.formatCurrency(cf.investing);
        document.getElementById('cf-financing').textContent = this.formatCurrency(cf.financing);
        document.getElementById('cf-net').textContent = this.formatCurrency(cf.netCashFlow);
        document.getElementById('cf-beginning').textContent = this.formatCurrency(cf.beginningCash);
        document.getElementById('cf-ending').textContent = this.formatCurrency(cf.endingCash);
    }

    calculateHealthScore() {
        const ratios = this.financialData.ratios;
        let score = 0;

        score += Math.min(ratios.grossMargin / 2, 25);
        score += Math.min(ratios.netMargin * 2, 25);
        score += Math.min(ratios.roe / 2, 25);
        score += Math.min(ratios.currentRatio * 10, 25);

        score = Math.round(score);
        document.getElementById('healthScore').textContent = score;

        const badge = document.getElementById('healthBadge');
        if (score >= 80) {
            badge.textContent = 'Excellent';
            badge.className = 'badge bg-success';
        } else if (score >= 60) {
            badge.textContent = 'Good';
            badge.className = 'badge bg-info';
        } else if (score >= 40) {
            badge.textContent = 'Fair';
            badge.className = 'badge bg-warning';
        } else {
            badge.textContent = 'Poor';
            badge.className = 'badge bg-danger';
        }

        if (this.charts.healthScoreChart) {
            this.updateHealthScoreChart(score);
        }
    }

    initializeCharts() {
        this.createRevenueChart();
        this.createExpenseChart();
        this.createProfitabilityChart();
        this.createHealthScoreChart();
        this.createTrendChart();
        this.createRevenueForecastChart();
        this.createCashFlowForecastChart();
        this.createBudgetChart();
        this.createScenarioChart();
    }

    createRevenueChart() {
        const ctx = document.getElementById('revenueChart').getContext('2d');
        this.charts.revenueChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: this.financialData.months,
                datasets: [{
                    label: 'Revenue',
                    data: this.financialData.revenue,
                    borderColor: '#0d6efd',
                    backgroundColor: 'rgba(13, 110, 253, 0.1)',
                    tension: 0.4,
                    fill: true
                }, {
                    label: 'Net Profit',
                    data: this.financialData.netProfit,
                    borderColor: '#198754',
                    backgroundColor: 'rgba(25, 135, 84, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top'
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return '$' + (value / 1000) + 'K';
                            }
                        }
                    }
                }
            }
        });
    }

    createExpenseChart() {
        const ctx = document.getElementById('expenseChart').getContext('2d');
        const expenses = this.financialData.expenseBreakdown;
        
        this.charts.expenseChart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: Object.keys(expenses).map(key => key.charAt(0).toUpperCase() + key.slice(1)),
                datasets: [{
                    data: Object.values(expenses),
                    backgroundColor: [
                        '#0d6efd',
                        '#198754',
                        '#ffc107',
                        '#dc3545',
                        '#0dcaf0',
                        '#6c757d'
                    ]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
    }

    createProfitabilityChart() {
        const ctx = document.getElementById('profitabilityChart').getContext('2d');
        const ratios = this.financialData.ratios;
        
        this.charts.profitabilityChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Gross Margin', 'Net Margin', 'ROE', 'ROA'],
                datasets: [{
                    label: 'Percentage',
                    data: [ratios.grossMargin, ratios.netMargin, ratios.roe, ratios.roa],
                    backgroundColor: [
                        'rgba(13, 110, 253, 0.8)',
                        'rgba(25, 135, 84, 0.8)',
                        'rgba(255, 193, 7, 0.8)',
                        'rgba(220, 53, 69, 0.8)'
                    ]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return value + '%';
                            }
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    }
                }
            }
        });
    }

    createHealthScoreChart() {
        const ctx = document.getElementById('healthScoreChart').getContext('2d');
        
        this.charts.healthScoreChart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                datasets: [{
                    data: [75, 25],
                    backgroundColor: ['#0d6efd', '#e9ecef'],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: '80%',
                plugins: {
                    legend: {
                        display: false
                    }
                }
            }
        });
    }

    updateHealthScoreChart(score) {
        this.charts.healthScoreChart.data.datasets[0].data = [score, 100 - score];
        this.charts.healthScoreChart.update();
    }

    createTrendChart() {
        const ctx = document.getElementById('trendChart').getContext('2d');
        
        this.charts.trendChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: this.financialData.months,
                datasets: [{
                    label: 'Revenue',
                    data: this.financialData.revenue,
                    borderColor: '#0d6efd',
                    tension: 0.4
                }, {
                    label: 'Expenses',
                    data: this.financialData.expenses,
                    borderColor: '#dc3545',
                    tension: 0.4
                }, {
                    label: 'Cash Flow',
                    data: this.financialData.cashFlow,
                    borderColor: '#198754',
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return '$' + (value / 1000) + 'K';
                            }
                        }
                    }
                }
            }
        });
    }

    createRevenueForecastChart() {
        const ctx = document.getElementById('revenueForecastChart').getContext('2d');
        const forecastMonths = ['Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        const forecastRevenue = this.generateForecast(this.financialData.revenue, 6, 0.08);
        
        this.charts.revenueForecastChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: [...this.financialData.months, ...forecastMonths],
                datasets: [{
                    label: 'Actual Revenue',
                    data: [...this.financialData.revenue, ...Array(6).fill(null)],
                    borderColor: '#0d6efd',
                    backgroundColor: 'rgba(13, 110, 253, 0.1)',
                    tension: 0.4
                }, {
                    label: 'Forecast Revenue',
                    data: [...Array(6).fill(null), ...forecastRevenue],
                    borderColor: '#ffc107',
                    backgroundColor: 'rgba(255, 193, 7, 0.1)',
                    borderDash: [5, 5],
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return '$' + (value / 1000) + 'K';
                            }
                        }
                    }
                }
            }
        });
    }

    createCashFlowForecastChart() {
        const ctx = document.getElementById('cashFlowForecastChart').getContext('2d');
        const forecastMonths = ['Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        const forecastCashFlow = this.generateForecast(this.financialData.cashFlow, 6, 0.05);
        
        this.charts.cashFlowForecastChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: [...this.financialData.months, ...forecastMonths],
                datasets: [{
                    label: 'Actual Cash Flow',
                    data: [...this.financialData.cashFlow, ...Array(6).fill(null)],
                    backgroundColor: 'rgba(25, 135, 84, 0.8)'
                }, {
                    label: 'Forecast Cash Flow',
                    data: [...Array(6).fill(null), ...forecastCashFlow],
                    backgroundColor: 'rgba(255, 193, 7, 0.8)'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return '$' + (value / 1000) + 'K';
                            }
                        }
                    }
                }
            }
        });
    }

    createBudgetChart() {
        const ctx = document.getElementById('budgetChart').getContext('2d');
        const budgetData = [50000, 55000, 52000, 60000, 65000, 62000];
        
        this.charts.budgetChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: this.financialData.months,
                datasets: [{
                    label: 'Budget',
                    data: budgetData,
                    backgroundColor: 'rgba(108, 117, 125, 0.5)',
                    borderColor: '#6c757d',
                    borderWidth: 1
                }, {
                    label: 'Actual',
                    data: this.financialData.revenue,
                    backgroundColor: 'rgba(13, 110, 253, 0.8)',
                    borderColor: '#0d6efd',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return '$' + (value / 1000) + 'K';
                            }
                        }
                    }
                }
            }
        });
    }

    createScenarioChart() {
        const ctx = document.getElementById('scenarioChart').getContext('2d');
        
        this.charts.scenarioChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['Current', '3M', '6M', '9M', '12M'],
                datasets: [{
                    label: 'Optimistic',
                    data: [58000, 63000, 68000, 74000, 80000],
                    borderColor: '#198754',
                    backgroundColor: 'rgba(25, 135, 84, 0.1)',
                    tension: 0.4
                }, {
                    label: 'Realistic',
                    data: [58000, 61000, 64000, 67000, 70000],
                    borderColor: '#0d6efd',
                    backgroundColor: 'rgba(13, 110, 253, 0.1)',
                    tension: 0.4
                }, {
                    label: 'Pessimistic',
                    data: [58000, 57000, 56000, 55000, 54000],
                    borderColor: '#dc3545',
                    backgroundColor: 'rgba(220, 53, 69, 0.1)',
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return '$' + (value / 1000) + 'K';
                            }
                        }
                    }
                }
            }
        });
    }

    generateForecast(data, periods, growthRate) {
        const forecast = [];
        const lastValue = data[data.length - 1];
        
        for (let i = 1; i <= periods; i++) {
            const seasonalFactor = 1 + 0.1 * Math.sin(i * Math.PI / 6);
            const trendValue = lastValue * Math.pow(1 + growthRate, i);
            const forecastValue = Math.round(trendValue * seasonalFactor);
            forecast.push(forecastValue);
        }
        
        return forecast;
    }

    formatCurrency(amount) {
        return new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'USD',
            minimumFractionDigits: 0,
            maximumFractionDigits: 0
        }).format(amount);
    }

    updateLastUpdated() {
        const now = new Date();
        const formatted = now.toLocaleString('en-US', {
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
        document.getElementById('lastUpdated').textContent = formatted;
    }

    bindEvents() {
        const growthRateSlider = document.getElementById('growthRate');
        growthRateSlider.addEventListener('input', (e) => {
            document.getElementById('growthRateValue').textContent = e.target.value;
        });
    }

    refreshDashboard() {
        this.loadSampleData();
        Object.values(this.charts).forEach(chart => {
            if (chart && typeof chart.update === 'function') {
                chart.update();
            }
        });
        this.updateLastUpdated();
        
        document.querySelector('.main-content').classList.add('data-updated');
        setTimeout(() => {
            document.querySelector('.main-content').classList.remove('data-updated');
        }, 2000);
    }

    updateDateRange() {
        const range = document.getElementById('dateRange').value;
        this.dateRange = parseInt(range);
        
        let months, revenue, expenses, netProfit, cashFlow;
        
        switch(this.dateRange) {
            case 1:
                months = ['Jun'];
                revenue = [58000];
                expenses = [47000];
                netProfit = [11000];
                cashFlow = [16000];
                break;
            case 3:
                months = ['Apr', 'May', 'Jun'];
                revenue = [55000, 62000, 58000];
                expenses = [46000, 51000, 47000];
                netProfit = [9000, 11000, 11000];
                cashFlow = [14000, 18000, 16000];
                break;
            case 12:
                months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
                revenue = [45000, 52000, 48000, 55000, 62000, 58000, 61000, 64000, 59000, 66000, 70000, 68000];
                expenses = [38000, 42000, 41000, 46000, 51000, 47000, 49000, 52000, 48000, 54000, 57000, 55000];
                netProfit = [7000, 10000, 7000, 9000, 11000, 11000, 12000, 12000, 11000, 12000, 13000, 13000];
                cashFlow = [12000, 15000, 8000, 14000, 18000, 16000, 17000, 19000, 15000, 18000, 21000, 19000];
                break;
            default:
                return;
        }
        
        this.financialData.months = months;
        this.financialData.revenue = revenue;
        this.financialData.expenses = expenses;
        this.financialData.netProfit = netProfit;
        this.financialData.cashFlow = cashFlow;
        
        this.updateMetrics();
        this.updateChartData();
    }

    updateChartData() {
        if (this.charts.revenueChart) {
            this.charts.revenueChart.data.labels = this.financialData.months;
            this.charts.revenueChart.data.datasets[0].data = this.financialData.revenue;
            this.charts.revenueChart.data.datasets[1].data = this.financialData.netProfit;
            this.charts.revenueChart.update();
        }
        
        if (this.charts.trendChart) {
            this.charts.trendChart.data.labels = this.financialData.months;
            this.charts.trendChart.data.datasets[0].data = this.financialData.revenue;
            this.charts.trendChart.data.datasets[1].data = this.financialData.expenses;
            this.charts.trendChart.data.datasets[2].data = this.financialData.cashFlow;
            this.charts.trendChart.update();
        }
    }

    updateScenario() {
        const scenarioType = document.getElementById('scenarioType').value;
        const growthRate = parseInt(document.getElementById('growthRate').value) / 100;
        const timeHorizon = parseInt(document.getElementById('timeHorizon').value);
        
        let multipliers;
        switch(scenarioType) {
            case 'optimistic':
                multipliers = [1.2, 1.15, 1.1];
                break;
            case 'pessimistic':
                multipliers = [0.8, 0.9, 0.95];
                break;
            default:
                multipliers = [1.0, 1.0, 1.0];
        }
        
        const baseRevenue = 58000;
        const periods = ['Current', '3M', '6M', '9M', '12M', '18M', '24M'].slice(0, Math.min(timeHorizon / 3 + 2, 7));
        
        const optimisticData = [];
        const realisticData = [];
        const pessimisticData = [];
        
        for (let i = 0; i < periods.length; i++) {
            const monthlyGrowth = Math.pow(1 + growthRate, i * 3);
            optimisticData.push(Math.round(baseRevenue * monthlyGrowth * 1.2));
            realisticData.push(Math.round(baseRevenue * monthlyGrowth));
            pessimisticData.push(Math.round(baseRevenue * monthlyGrowth * 0.8));
        }
        
        this.charts.scenarioChart.data.labels = periods;
        this.charts.scenarioChart.data.datasets[0].data = optimisticData;
        this.charts.scenarioChart.data.datasets[1].data = realisticData;
        this.charts.scenarioChart.data.datasets[2].data = pessimisticData;
        this.charts.scenarioChart.update();
    }

    exportReport() {
        const reportData = {
            company: 'ABC Corporation',
            reportDate: new Date().toISOString().split('T')[0],
            metrics: {
                totalRevenue: document.getElementById('totalRevenue').textContent,
                netProfit: document.getElementById('netProfit').textContent,
                cashFlow: document.getElementById('cashFlow').textContent,
                profitMargin: document.getElementById('profitMargin').textContent
            },
            healthScore: document.getElementById('healthScore').textContent,
            statements: this.financialData
        };
        
        const dataStr = JSON.stringify(reportData, null, 2);
        const dataBlob = new Blob([dataStr], {type: 'application/json'});
        
        const link = document.createElement('a');
        link.href = URL.createObjectURL(dataBlob);
        link.download = `financial-report-${reportData.reportDate}.json`;
        link.click();
    }
}

const dashboard = new FinancialDashboard();

function loadSampleData() {
    dashboard.loadSampleData();
    dashboard.refreshDashboard();
}

function exportReport() {
    dashboard.exportReport();
}

function refreshDashboard() {
    dashboard.refreshDashboard();
}

function updateDateRange() {
    dashboard.updateDateRange();
}

function updateScenario() {
    dashboard.updateScenario();
}
