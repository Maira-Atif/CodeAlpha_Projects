# Financial Health Dashboard

A comprehensive web-based financial dashboard designed for small to medium enterprises to analyze their financial status with real-time insights.

## Features

### 📊 Financial Visualizations
- **Income Statement Analysis** - Complete profit & loss breakdown
- **Balance Sheet Overview** - Assets, liabilities, and equity tracking
- **Cash Flow Statement** - Operating, investing, and financing activities
- **Expense Breakdown** - Visual representation of cost categories

### 📈 Analytics & Insights
- **Profitability Trends** - Track revenue, expenses, and profit margins over time
- **Financial Health Score** - Comprehensive scoring system based on key ratios
- **Key Performance Indicators** - Real-time metrics with trend indicators
- **Ratio Analysis** - Gross margin, net margin, ROE, ROA calculations

### 🔮 Forecasting & Planning
- **Revenue Forecasting** - Predictive models for future revenue streams
- **Cash Flow Projections** - Future cash position analysis
- **Scenario Planning** - Optimistic, realistic, and pessimistic scenarios
- **Budget vs Actual** - Performance tracking against budget targets

### 🎛️ Interactive Features
- **Dynamic Date Ranges** - 1, 3, 6, or 12-month views
- **Real-time Updates** - Instant data refresh capabilities
- **Export Functionality** - Download reports in JSON format
- **Responsive Design** - Works on desktop, tablet, and mobile devices

## Technologies Used

- **Frontend**: HTML5, CSS3, JavaScript (ES6+)
- **Visualization**: Chart.js for interactive charts
- **UI Framework**: Bootstrap 5 for responsive design
- **Icons**: Font Awesome for professional iconography
- **Data Storage**: Local storage for data persistence

## Getting Started

### Prerequisites
- Modern web browser (Chrome, Firefox, Safari, Edge)
- No server installation required

### Installation

1. **Clone or Download** the project files
2. **Open** `index.html` in your web browser
3. **Load Sample Data** using the "Load Sample Data" button
4. **Explore** the different sections of the dashboard

### Quick Start

1. Open the dashboard in your browser
2. Click "Load Sample Data" to populate with demo financial data
3. Navigate through different sections:
   - **Overview**: Key metrics and trends
   - **Statements**: Detailed financial statements
   - **Analysis**: Profitability and health analysis
   - **Forecasting**: Future projections and scenarios

## Dashboard Sections

### 1. Financial Overview
- Total Revenue with growth percentage
- Net Profit tracking
- Cash Flow monitoring
- Profit Margin analysis
- Revenue & Profit trend charts
- Expense breakdown pie chart

### 2. Financial Statements
#### Income Statement
- Revenue and cost of goods sold
- Gross profit calculation
- Operating expenses and income
- Interest expenses
- Net income

#### Balance Sheet
- Current and fixed assets
- Current liabilities and long-term debt
- Equity calculations
- Total assets balancing

#### Cash Flow Statement
- Operating cash flow
- Investing activities
- Financing activities
- Net cash flow
- Beginning and ending cash positions

### 3. Profitability Analysis
- Key financial ratios visualization
- Financial health score (0-100)
- Monthly trend analysis
- Performance indicators

### 4. Financial Forecasting
- 6-month revenue projections
- Cash flow forecasting
- Budget vs actual comparisons
- Scenario planning tools
- Key predictions and insights

## Key Metrics Explained

### Financial Health Score
Calculated based on:
- **Gross Margin** (25 points max)
- **Net Margin** (25 points max)
- **Return on Equity** (25 points max)
- **Current Ratio** (25 points max)

### Profitability Ratios
- **Gross Margin**: (Revenue - COGS) / Revenue
- **Net Margin**: Net Income / Revenue
- **ROE**: Net Income / Shareholder Equity
- **ROA**: Net Income / Total Assets

## Data Management

### Sample Data Structure
The dashboard uses structured financial data including:
- Monthly revenue and expense data
- Income statement line items
- Balance sheet accounts
- Cash flow components
- Financial ratios and metrics

### Data Import/Export
- **Export**: Download current financial report as JSON
- **Refresh**: Update all data and recalculate metrics
- **Date Range**: Filter data by time periods

## Customization

### Adding New Metrics
1. Update the `financialData` object in `script.js`
2. Add corresponding HTML elements
3. Create calculation functions
4. Update chart configurations

### Styling Modifications
- Edit `styles.css` for visual customizations
- Modify Bootstrap classes for layout changes
- Update color schemes in CSS variables

### Chart Customization
- Charts use Chart.js library
- Modify chart options in the `initializeCharts()` function
- Add new chart types as needed

## Browser Compatibility

- ✅ Chrome 80+
- ✅ Firefox 75+
- ✅ Safari 13+
- ✅ Edge 80+
- ✅ Mobile browsers

## Performance Optimization

### Best Practices Implemented
- Efficient DOM manipulation
- Optimized chart rendering
- Responsive image loading
- Minimal external dependencies
- CSS and JavaScript minification ready

### Loading Performance
- CDN-hosted libraries for faster loading
- Optimized chart animations
- Lazy loading for non-critical elements

## Security Considerations

- Client-side only implementation
- No sensitive data transmission
- Local storage for temporary data
- No external API dependencies

## Future Enhancements

### Planned Features
- Database integration for persistent storage
- Advanced forecasting algorithms
- Industry benchmarking
- Multi-company support
- Advanced reporting templates
- API integrations for real-time data

### Technical Improvements
- Progressive Web App (PWA) capabilities
- Offline functionality
- Advanced data validation
- Custom chart types
- Enhanced mobile experience

## Troubleshooting

### Common Issues

1. **Charts not displaying**
   - Ensure Chart.js CDN is accessible
   - Check browser console for errors
   - Verify JavaScript is enabled

2. **Data not updating**
   - Click "Refresh Data" button
   - Clear browser cache
   - Reload the page

3. **Mobile display issues**
   - Ensure viewport meta tag is present
   - Check Bootstrap CSS loading
   - Test in device-specific browsers

### Support
For technical support or feature requests, please check the browser console for error messages and ensure all CDN resources are loading properly.

## License

This project is open source and available under the MIT License.

## Contributing

Contributions are welcome! Please feel free to:
- Report bugs and issues
- Suggest new features
- Submit pull requests
- Improve documentation

## Acknowledgments

- Chart.js for excellent charting capabilities
- Bootstrap for responsive framework
- Font Awesome for iconography
- Modern web standards for browser compatibility
