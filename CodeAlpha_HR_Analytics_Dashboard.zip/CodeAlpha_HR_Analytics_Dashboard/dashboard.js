// HR Analytics Dashboard - Data Visualization Platform
class WorkforceAnalytics {
    constructor() {
        this.activeSection = 'overview';
        this.chartInstances = {};
        this.workforceData = this.initializeDataSets();
        this.setupDashboard();
    }

    initializeDataSets() {
        return {
            workforce: {
                totalEmployees: 1247,
                newHires: 43,
                turnoverPercentage: 3.2,
                satisfactionRating: 4.3
            },
            growthMetrics: {
                months: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                employeeCount: [1180, 1195, 1210, 1225, 1235, 1247]
            },
            departmentBreakdown: {
                departments: ['Engineering', 'Sales', 'Marketing', 'HR', 'Operations', 'Finance'],
                headcount: [425, 280, 165, 85, 182, 110]
            },
            recruitmentData: {
                openRoles: 24,
                totalApplications: 186,
                interviewConversion: 32,
                hireSuccess: 23,
                applicationFunnel: [186, 89, 45, 24],
                averageHiringTime: [15, 18, 22, 25, 20, 19]
            },
            performanceMetrics: {
                ratingDistribution: [15, 45, 280, 520, 387],
                departmentPerformance: [4.2, 4.1, 3.9, 4.0, 3.8, 4.3]
            },
            attritionAnalysis: {
                departmentTurnover: [2.1, 4.2, 3.5, 1.8, 4.8, 2.3],
                retentionByTenure: [95, 92, 88, 85, 82, 80]
            },
            engagementData: {
                quarterlyTrends: [4.1, 4.0, 4.2, 4.1, 4.3, 4.3],
                satisfactionAreas: {
                    overall: 4.3,
                    workLifeBalance: 4.1,
                    careerGrowth: 3.9,
                    leadership: 4.2
                }
            },
            forecastModels: {
                projectedHiring: [12, 15, 18, 22, 19, 16],
                attritionRisk: 23
            }
        };
    }

    setupDashboard() {
        this.initializeNavigation();
        this.configureDateFilters();
        this.renderAllCharts();
        this.startDataRefresh();
        this.enableAnimations();
    }

    initializeNavigation() {
        const navigationLinks = document.querySelectorAll('.nav-item a');
        navigationLinks.forEach(link => {
            link.addEventListener('click', (event) => {
                event.preventDefault();
                const targetSection = link.getAttribute('data-section');
                this.navigateToSection(targetSection);
            });
        });
    }

    navigateToSection(sectionName) {
        // Update navigation state
        document.querySelectorAll('.nav-item').forEach(item => {
            item.classList.remove('active');
        });
        document.querySelector(`[data-section="${sectionName}"]`).parentElement.classList.add('active');

        // Switch content sections
        document.querySelectorAll('.dashboard-section').forEach(section => {
            section.classList.remove('active');
        });
        document.getElementById(`${sectionName}-section`).classList.add('active');

        // Update page header
        this.updatePageHeader(sectionName);
        this.activeSection = sectionName;

        // Refresh charts for active section
        setTimeout(() => this.refreshSectionCharts(sectionName), 150);
    }

    updatePageHeader(section) {
        const headerConfig = {
            overview: { title: 'HR Analytics Overview', subtitle: 'Comprehensive workforce insights and analytics' },
            recruitment: { title: 'Recruitment Analytics', subtitle: 'Track hiring funnel and recruitment efficiency' },
            performance: { title: 'Performance Analytics', subtitle: 'Employee performance metrics and trends' },
            turnover: { title: 'Turnover Analysis', subtitle: 'Analyze employee retention and departure patterns' },
            satisfaction: { title: 'Employee Satisfaction', subtitle: 'Monitor employee engagement and satisfaction levels' },
            predictions: { title: 'Predictive Analytics', subtitle: 'Data-driven insights for future workforce planning' }
        };

        document.getElementById('page-title').textContent = headerConfig[section].title;
        document.getElementById('page-subtitle').textContent = headerConfig[section].subtitle;
    }

    configureDateFilters() {
        const dateFilter = document.getElementById('dateRange');
        dateFilter.addEventListener('change', (event) => {
            this.updateDataByPeriod(event.target.value);
        });
    }

    updateDataByPeriod(periodDays) {
        const adjustmentFactor = periodDays / 30;
        this.workforceData.workforce.newHires = Math.round(43 * adjustmentFactor);
        this.updateAllCharts();
        this.animateMetricUpdates();
    }

    renderAllCharts() {
        this.createEmployeeGrowthChart();
        this.createDepartmentDistributionChart();
        this.createRecruitmentFunnelChart();
        this.createHiringTimeChart();
        this.createPerformanceDistributionChart();
        this.createDepartmentPerformanceChart();
        this.createTurnoverAnalysisChart();
        this.createRetentionChart();
        this.createSatisfactionTrendChart();
        this.createHiringForecastChart();
    }

    createEmployeeGrowthChart() {
        const chartContext = document.getElementById('growthChart').getContext('2d');
        this.chartInstances.employeeGrowth = new Chart(chartContext, {
            type: 'line',
            data: {
                labels: this.workforceData.growthMetrics.months,
                datasets: [{
                    label: 'Total Employees',
                    data: this.workforceData.growthMetrics.employeeCount,
                    borderColor: '#667eea',
                    backgroundColor: 'rgba(102, 126, 234, 0.1)',
                    fill: true,
                    tension: 0.4,
                    pointBackgroundColor: '#667eea',
                    pointBorderColor: '#fff',
                    pointBorderWidth: 2,
                    pointRadius: 6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: false,
                        grid: {
                            color: 'rgba(0, 0, 0, 0.1)'
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });
    }

    createDepartmentDistributionChart() {
        const chartContext = document.getElementById('departmentChart').getContext('2d');
        this.chartInstances.departmentDistribution = new Chart(chartContext, {
            type: 'doughnut',
            data: {
                labels: this.workforceData.departmentBreakdown.departments,
                datasets: [{
                    data: this.workforceData.departmentBreakdown.headcount,
                    backgroundColor: [
                        '#667eea',
                        '#764ba2',
                        '#f093fb',
                        '#f5576c',
                        '#4facfe',
                        '#00f2fe'
                    ],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            usePointStyle: true,
                            padding: 20
                        }
                    }
                }
            }
        });
    }

    createRecruitmentFunnelChart() {
        const chartContext = document.getElementById('funnelChart').getContext('2d');
        this.chartInstances.recruitmentFunnel = new Chart(chartContext, {
            type: 'bar',
            data: {
                labels: ['Applications', 'Screened', 'Interviewed', 'Hired'],
                datasets: [{
                    data: this.workforceData.recruitmentData.applicationFunnel,
                    backgroundColor: [
                        'rgba(102, 126, 234, 0.8)',
                        'rgba(102, 126, 234, 0.6)',
                        'rgba(102, 126, 234, 0.4)',
                        'rgba(102, 126, 234, 1)'
                    ],
                    borderRadius: 8
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(0, 0, 0, 0.1)'
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });
    }

    createHiringTimeChart() {
        const chartContext = document.getElementById('timeToHireChart').getContext('2d');
        this.chartInstances.hiringTime = new Chart(chartContext, {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                datasets: [{
                    label: 'Days to Hire',
                    data: this.workforceData.recruitmentData.averageHiringTime,
                    borderColor: '#764ba2',
                    backgroundColor: 'rgba(118, 75, 162, 0.1)',
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(0, 0, 0, 0.1)'
                        }
                    }
                }
            }
        });
    }

    createPerformanceDistributionChart() {
        const chartContext = document.getElementById('performanceChart').getContext('2d');
        this.chartInstances.performanceDistribution = new Chart(chartContext, {
            type: 'bar',
            data: {
                labels: ['Needs Improvement', 'Below Average', 'Average', 'Above Average', 'Excellent'],
                datasets: [{
                    data: this.workforceData.performanceMetrics.ratingDistribution,
                    backgroundColor: [
                        '#f5576c',
                        '#f093fb',
                        '#4facfe',
                        '#667eea',
                        '#764ba2'
                    ],
                    borderRadius: 8
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(0, 0, 0, 0.1)'
                        }
                    }
                }
            }
        });
    }

    createDepartmentPerformanceChart() {
        const chartContext = document.getElementById('deptPerformanceChart').getContext('2d');
        this.chartInstances.departmentPerformance = new Chart(chartContext, {
            type: 'radar',
            data: {
                labels: this.workforceData.departmentBreakdown.departments,
                datasets: [{
                    label: 'Performance Score',
                    data: this.workforceData.performanceMetrics.departmentPerformance,
                    borderColor: '#667eea',
                    backgroundColor: 'rgba(102, 126, 234, 0.2)',
                    pointBackgroundColor: '#667eea'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    r: {
                        beginAtZero: true,
                        max: 5,
                        grid: {
                            color: 'rgba(0, 0, 0, 0.1)'
                        }
                    }
                }
            }
        });
    }

    createTurnoverAnalysisChart() {
        const chartContext = document.getElementById('turnoverChart').getContext('2d');
        this.chartInstances.turnoverAnalysis = new Chart(chartContext, {
            type: 'bar',
            data: {
                labels: this.workforceData.departmentBreakdown.departments,
                datasets: [{
                    label: 'Turnover Rate (%)',
                    data: this.workforceData.attritionAnalysis.departmentTurnover,
                    backgroundColor: 'rgba(245, 87, 108, 0.8)',
                    borderRadius: 8
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(0, 0, 0, 0.1)'
                        }
                    }
                }
            }
        });
    }

    createRetentionChart() {
        const chartContext = document.getElementById('retentionChart').getContext('2d');
        this.chartInstances.retention = new Chart(chartContext, {
            type: 'line',
            data: {
                labels: ['0-6 months', '6-12 months', '1-2 years', '2-3 years', '3-4 years', '4+ years'],
                datasets: [{
                    label: 'Retention Rate (%)',
                    data: this.workforceData.attritionAnalysis.retentionByTenure,
                    borderColor: '#4facfe',
                    backgroundColor: 'rgba(79, 172, 254, 0.1)',
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100,
                        grid: {
                            color: 'rgba(0, 0, 0, 0.1)'
                        }
                    }
                }
            }
        });
    }

    createSatisfactionTrendChart() {
        const chartContext = document.getElementById('satisfactionChart').getContext('2d');
        this.chartInstances.satisfactionTrend = new Chart(chartContext, {
            type: 'line',
            data: {
                labels: ['Q1 2024', 'Q2 2024', 'Q3 2024', 'Q4 2024', 'Q1 2025', 'Q2 2025'],
                datasets: [{
                    label: 'Satisfaction Score',
                    data: this.workforceData.engagementData.quarterlyTrends,
                    borderColor: '#00f2fe',
                    backgroundColor: 'rgba(0, 242, 254, 0.1)',
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: false,
                        min: 3,
                        max: 5,
                        grid: {
                            color: 'rgba(0, 0, 0, 0.1)'
                        }
                    }
                }
            }
        });
    }

    createHiringForecastChart() {
        const chartContext = document.getElementById('predictionChart').getContext('2d');
        this.chartInstances.hiringForecast = new Chart(chartContext, {
            type: 'bar',
            data: {
                labels: ['Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                datasets: [{
                    label: 'Predicted Hires',
                    data: this.workforceData.forecastModels.projectedHiring,
                    backgroundColor: 'rgba(102, 126, 234, 0.8)',
                    borderRadius: 8
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(0, 0, 0, 0.1)'
                        }
                    }
                }
            }
        });
    }

    refreshSectionCharts(section) {
        switch (section) {
            case 'overview':
                if (this.chartInstances.employeeGrowth) this.chartInstances.employeeGrowth.update();
                if (this.chartInstances.departmentDistribution) this.chartInstances.departmentDistribution.update();
                break;
            case 'recruitment':
                if (this.chartInstances.recruitmentFunnel) this.chartInstances.recruitmentFunnel.update();
                if (this.chartInstances.hiringTime) this.chartInstances.hiringTime.update();
                break;
            case 'performance':
                if (this.chartInstances.performanceDistribution) this.chartInstances.performanceDistribution.update();
                if (this.chartInstances.departmentPerformance) this.chartInstances.departmentPerformance.update();
                break;
            case 'turnover':
                if (this.chartInstances.turnoverAnalysis) this.chartInstances.turnoverAnalysis.update();
                if (this.chartInstances.retention) this.chartInstances.retention.update();
                break;
            case 'satisfaction':
                if (this.chartInstances.satisfactionTrend) this.chartInstances.satisfactionTrend.update();
                break;
            case 'predictions':
                if (this.chartInstances.hiringForecast) this.chartInstances.hiringForecast.update();
                break;
        }
    }

    updateAllCharts() {
        Object.values(this.chartInstances).forEach(chart => {
            if (chart) chart.update();
        });
    }

    enableAnimations() {
        const observerConfig = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };

        const elementObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('animate-in');
                }
            });
        }, observerConfig);

        document.querySelectorAll('.metric-card, .chart-container').forEach(element => {
            elementObserver.observe(element);
        });
    }

    animateMetricUpdates() {
        const metricCards = document.querySelectorAll('.metric-card');
        metricCards.forEach((card, index) => {
            setTimeout(() => {
                card.classList.add('loading');
                setTimeout(() => {
                    card.classList.remove('loading');
                }, 1000);
            }, index * 200);
        });
    }

    startDataRefresh() {
        setInterval(() => {
            // Simulate live data updates
            this.workforceData.workforce.totalEmployees += Math.floor(Math.random() * 3) - 1;
            this.workforceData.workforce.satisfactionRating += (Math.random() - 0.5) * 0.1;
            
            // Update displayed metrics
            const employeeCountElement = document.querySelector('.metric-card .metric-value');
            if (employeeCountElement) {
                employeeCountElement.textContent = this.workforceData.workforce.totalEmployees.toLocaleString();
            }
            
            // Refresh all visualizations
            this.updateAllCharts();
        }, 30000);
    }
}

// Report Export Functionality
function exportReport() {
    const exportButton = document.querySelector('.export-btn');
    const buttonText = exportButton.innerHTML;
    
    exportButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Exporting...';
    exportButton.disabled = true;
    
    setTimeout(() => {
        exportButton.innerHTML = '<i class="fas fa-check"></i> Export Complete';
        
        setTimeout(() => {
            exportButton.innerHTML = buttonText;
            exportButton.disabled = false;
        }, 2000);
        
        // Generate downloadable report
        const downloadLink = document.createElement('a');
        downloadLink.href = 'data:text/plain;charset=utf-8,HR Analytics Report - Generated on ' + new Date().toLocaleDateString();
        downloadLink.download = 'hr-analytics-report.txt';
        document.body.appendChild(downloadLink);
        downloadLink.click();
        document.body.removeChild(downloadLink);
    }, 2000);
}

// Dashboard Initialization
document.addEventListener('DOMContentLoaded', () => {
    new WorkforceAnalytics();
    
    // Add animation styles
    const animationStyles = document.createElement('style');
    animationStyles.textContent = `
        .animate-in {
            animation: slideUpFade 0.6s ease forwards;
        }
        
        @keyframes slideUpFade {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .metric-card {
            opacity: 0;
            transform: translateY(30px);
            transition: all 0.6s ease;
        }
        
        .metric-card.animate-in {
            opacity: 1;
            transform: translateY(0);
        }
    `;
    document.head.appendChild(animationStyles);
});
